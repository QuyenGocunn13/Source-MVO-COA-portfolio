import requests
from bs4 import BeautifulSoup
import csv
from pathlib import Path

def fetch_and_save_lai_suat_lien_ngan_hang(filename="lai_suat_lien_ngan_hang.csv"):
    # ===== Đường dẫn =====
    BASE_DIR = Path(__file__).resolve().parent
    DATABASE_DIR = BASE_DIR / "database"
    DATABASE_DIR.mkdir(exist_ok=True)  
    
    save_path = DATABASE_DIR / filename
    
    url = "https://dttktt.sbv.gov.vn/webcenter/portal/vi/menu/rm/ls"
    response = requests.get(url)
    response.encoding = "utf-8"

    soup = BeautifulSoup(response.text, "html.parser")

    ngay_ap_dung_span = soup.find("span", string=lambda x: x and "Ngày áp dụng" in x)
    if ngay_ap_dung_span:
        ngay_ap_dung = ngay_ap_dung_span.find_next("span").get_text(strip=True)
    else:
        ngay_ap_dung = None

    tables = soup.find_all("table", class_="jrPage")
    table2 = tables[1] if len(tables) > 1 else None

    lshn_data = []
    if table2:
        rows2 = table2.find_all("tr")
        for row in rows2:
            cols = [c.get_text(strip=True) for c in row.find_all("td")]

            if not cols or all(c == "" for c in cols):
                continue
            if "Thời hạn" in cols[0] or "Ghi chú" in cols[0]:
                continue

            if len(cols) == 3 and cols[0] and cols[1] and cols[2]:
                processed = []
                for col in cols:
                    val = col.replace(".", "").replace(",", ".")
                    try:
                        processed.append(float(val))
                    except ValueError:
                        processed.append(col)
                lshn_data.append([ngay_ap_dung] + processed)

    with open(save_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Ngày áp dụng", "Thời hạn", "Lãi suất BQ liên Ngân hàng (% năm)", "Doanh số (Tỷ đồng)"])
        writer.writerows(lshn_data)

    print(f"✅ Đã lưu {len(lshn_data)} dòng dữ liệu vào {save_path}")
    return len(lshn_data)
