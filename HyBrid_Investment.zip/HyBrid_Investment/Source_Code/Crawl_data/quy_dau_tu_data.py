from pathlib import Path
from vnstock import Fund
import pandas as pd
from datetime import datetime, timedelta

def fetch_and_save_nav_last_7_days(filename_prefix="nav"):
    # ===== Đường dẫn =====
    BASE_DIR = Path(__file__).resolve().parent
    DATABASE_DIR = BASE_DIR / "database"
    DATABASE_DIR.mkdir(exist_ok=True)  

    fund = Fund()

    # ===== Danh sách quỹ theo nhóm =====
    FUNDS = {
        "equity": ['SSISCA', 'VCBF-BCF', 'VESAF'],
        "balanced": ['VCBF-TBF', 'VIBF', 'MAFBAL'],
        "bond": ['VCBF-FIF', 'SSIBF', 'MBBOND']
    }

    def get_nav_data(fund_list):
        """Lấy dữ liệu NAV cho danh sách quỹ"""
        df_list = []
        for code in fund_list:
            try:
                df = fund.details.nav_report(code)
                df['fund_code'] = code
                df_list.append(df)
            except Exception as e:
                print(f"❌ Lỗi khi lấy dữ liệu {code}: {e}")
        return pd.concat(df_list, ignore_index=True) if df_list else pd.DataFrame()

    def filter_last_7_days(df):
        """Lọc dữ liệu 7 ngày gần nhất"""
        if df.empty:
            return df
        df['date'] = pd.to_datetime(df['date'])
        seven_days_ago = datetime.now() - timedelta(days=7)
        return df[df['date'] >= seven_days_ago].sort_values(by='date', ascending=False)

    total_rows = 0
    for group, codes in FUNDS.items():
        df_raw = get_nav_data(codes)
        df_last7 = filter_last_7_days(df_raw)

        # Lưu file
        save_path = DATABASE_DIR / f"{filename_prefix}_{group}_last_7_days.csv"
        df_last7.to_csv(save_path, index=False, encoding="utf-8-sig")

        print(f"✅ {group}: đã lưu {len(df_last7)} dòng → {save_path}")
        total_rows += len(df_last7)

    return total_rows

