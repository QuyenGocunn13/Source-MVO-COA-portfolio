from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATABASE_DIR = BASE_DIR / "database"

def fetch_real_estate_stocks(csv_path="real_estate_stocks.csv", headless=True, wait_time=10):
    """
    Lấy dữ liệu cổ phiếu bất động sản từ Vietstock và lưu vào CSV.
    
    csv_path : str : đường dẫn file CSV lưu dữ liệu
    headless : bool : chạy Chrome ở chế độ ẩn hay hiện cửa sổ
    wait_time : int : thời gian chờ tối đa cho dữ liệu load (giây)
    """
    # Cấu hình Chrome
    options = Options()
    if headless:
        options.add_argument("--headless")
    driver = webdriver.Chrome(options=options)
    driver.get("https://vietstock.vn/bat-dong-san/thi-truong-nha-dat.htm")
    
    # Chờ ít nhất 1 cổ phiếu xuất hiện
    try:
        WebDriverWait(driver, wait_time).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "div#stocksBDS .single_social"))
        )
    except:
        print("Không load được dữ liệu sau", wait_time, "giây")
        driver.quit()
        return
    
    rows = []
    items = driver.find_elements(By.CSS_SELECTOR, "div#stocksBDS .single_social")
    for item in items:
        code_elem = item.find_element(By.CSS_SELECTOR, ".fr-index")
        name_elem = item.find_element(By.CSS_SELECTOR, ".name-index a")
        price_elem = item.find_element(By.CSS_SELECTOR, ".cont-index .price")
        change_elem = item.find_element(By.CSS_SELECTOR, ".price-change")
        percent_elem = item.find_element(By.CSS_SELECTOR, ".percent-change")

        code = code_elem.get_attribute("code")
        name = name_elem.text
        price_text = price_elem.text.replace(",", "")
        try:
            price = float(price_text)
        except:
            price = None
        change = change_elem.text
        percent = percent_elem.text

        rows.append({
            "code": code,
            "name": name,
            "price": price,
            "change": change,
            "percent": percent
        })

    df = pd.DataFrame(rows)

    DATABASE_DIR.mkdir(parents=True, exist_ok=True)
    csv_file_path = DATABASE_DIR / csv_path


    df.to_csv(csv_file_path, index=False, encoding="utf-8-sig")
    print(f"Đã lưu dữ liệu vào file {csv_file_path}")
    driver.quit()
