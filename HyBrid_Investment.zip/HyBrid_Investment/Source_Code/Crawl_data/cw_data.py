from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd
from pathlib import Path
import time


def fetch_top10_cw(output_filename: str = "CW_data_top10.csv", headless: bool = False):
    """
    Hàm lấy 10 chứng quyền (CW) đầu tiên từ Vietstock
    và lưu vào file CSV trong thư mục `database/`.

    Args:
        output_filename (str): tên file CSV sẽ lưu (mặc định: CW_data_top10.csv)
        headless (bool): bật chế độ chạy nền (không mở cửa sổ Chrome)
    """

    # ===== Thư mục lưu file =====
    BASE_DIR = Path(__file__).resolve().parent
    download_dir = BASE_DIR / "database"
    download_dir.mkdir(exist_ok=True)
    file_path = download_dir / output_filename

    # ===== Cấu hình Chrome =====
    chrome_options = Options()
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    if headless:
        chrome_options.add_argument("--headless")

    driver = webdriver.Chrome(options=chrome_options)
    wait = WebDriverWait(driver, 20)

    try:
        # ===== Mở trang CW danh sách =====
        cw_url = "https://finance.vietstock.vn/chung-khoan-phai-sinh/chung-quyen.htm"
        driver.get(cw_url)

        # Chờ bảng dữ liệu hiển thị
        wait.until(EC.presence_of_element_located((By.ID, "cw-list")))
        time.sleep(2)

        # Lấy 10 hàng đầu tiên
        data = []
        rows = driver.find_elements(By.CSS_SELECTOR, "#cw-list tbody tr")[:10]
        for row in rows:
            cols = row.find_elements(By.TAG_NAME, "td")
            if cols:
                data.append([c.text.strip() for c in cols])

        # ===== Lưu CSV =====
        columns = [
            "STT", "Mã CW", "Giá đóng cửa", "Thay đổi", "Tỷ lệ chuyển đổi",
            "Giá thực hiện", "Chứng khoán cơ sở", "Tổ chức phát hành",
            "Loại CW", "Kiểu thực hiện", "Ngày GDĐT", "Ngày GDCC", "Trạng thái"
        ]
        df = pd.DataFrame(data, columns=columns)
        df.to_csv(file_path, index=False, encoding="utf-8-sig")

        print("✅ Đã lưu 10 dòng CW đầu tiên vào:", file_path)
        return file_path

    finally:
        driver.quit()
