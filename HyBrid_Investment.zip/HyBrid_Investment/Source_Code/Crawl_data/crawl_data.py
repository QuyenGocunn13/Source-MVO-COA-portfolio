from Crawl_data.data_bank import fetch_and_save_lai_suat_lien_ngan_hang
from Crawl_data.cw_data import fetch_top10_cw
from Crawl_data.bat_dong_san import fetch_real_estate_stocks
from Crawl_data.quy_dau_tu_data import fetch_and_save_nav_last_7_days

if __name__ == "__main__":
    fetch_and_save_lai_suat_lien_ngan_hang()
    fetch_top10_cw()
    fetch_real_estate_stocks()
    fetch_and_save_nav_last_7_days()
    print("✅ Đã hoàn thành các tác vụ lấy dữ liệu.")
    print("📊 Dữ liệu đã được lưu vào thư mục 'database'.")
