import psycopg2
from werkzeug.security import generate_password_hash

conn = psycopg2.connect(
    dbname='investment_db',     
    user='postgres',      
    password='rocky04052005@@',  
    host='db',
    port='5432'
)

cur = conn.cursor()
admin_email = 'iamrocky0405@gmail.com'
cur.execute("SELECT 1 FROM users WHERE email = %s", (admin_email,))
if not cur.fetchone():
    hashed_pw = generate_password_hash("admin123")
    cur.execute("""
        INSERT INTO users (full_name, email, password_hash, role)
        VALUES (%s, %s, %s, %s)
    """, ("Admin", admin_email, hashed_pw, "admin"))
    print("✅ Đã tạo tài khoản admin.")
else:
    print("⚠️  Admin đã tồn tại.")

conn.commit()
cur.close()
conn.close()
