# Tham số danh mục
class Algorithm_Investment:
    def __init__(self, positive_indices, negative_indices, diversification_index, investment_time_index):
        self.positive_indices = positive_indices
        self.negative_indices = negative_indices
        self.diversification_index = diversification_index
        self.investment_time_index = investment_time_index