import numpy as np
# Fitness của danh mục
class Fitness_Function_Investment:
    def __init__(self, criteria_manager, parameters):
        self.criteria_manager = criteria_manager
        self.parameters = parameters

    def fitness_function(self, i):
        if i < 0 or i >= self.criteria_manager.criteria_values.shape[0]:
            raise IndexError("Index i is out of bounds for criteria_values.")

        current_criteria_values = self.criteria_manager.criteria_values[i]
        sorted_indices = np.argsort(self.criteria_manager.weights)[-3:]

        # Sử dụng vector hóa để tính toán
        weights_vector = np.array(self.criteria_manager.weights)
        values_vector = np.array(current_criteria_values)
        weights_percent_vector = np.array(self.criteria_manager.weights_percent)

        positive_contribution = np.sum(
            weights_vector[self.parameters.positive_indices] *
            values_vector[self.parameters.positive_indices] *
            weights_percent_vector[self.parameters.positive_indices]
        )

        negative_contribution = np.sum(
            weights_vector[self.parameters.negative_indices] *
            values_vector[self.parameters.negative_indices] *
            weights_percent_vector[self.parameters.negative_indices]
        )

        # Điều chỉnh diversification và investment_time
        for idx in [self.parameters.diversification_index, self.parameters.investment_time_index]:
            contribution = weights_vector[idx] * values_vector[idx] * weights_percent_vector[idx]
            if idx in sorted_indices:
                positive_contribution += contribution
            else:
                positive_contribution -= contribution

        return (positive_contribution + 1) / (negative_contribution + 1)

