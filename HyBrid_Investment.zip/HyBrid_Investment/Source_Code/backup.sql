--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: deposits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.deposits (
    id integer NOT NULL,
    user_id integer,
    amount numeric(12,2) NOT NULL,
    method character varying(50),
    status character varying(20) DEFAULT 'pending'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.deposits OWNER TO postgres;

--
-- Name: deposits_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.deposits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.deposits_id_seq OWNER TO postgres;

--
-- Name: deposits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.deposits_id_seq OWNED BY public.deposits.id;


--
-- Name: notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification (
    id integer NOT NULL,
    email_user character varying(100) NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    is_read boolean DEFAULT false,
    create_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notification OWNER TO postgres;

--
-- Name: notification_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notification_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notification_id_seq OWNER TO postgres;

--
-- Name: notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notification_id_seq OWNED BY public.notification.id;


--
-- Name: recommendation_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recommendation_log (
    id integer NOT NULL,
    user_email character varying(100) NOT NULL,
    weights_json text,
    investments_json text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.recommendation_log OWNER TO postgres;

--
-- Name: recommendation_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recommendation_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recommendation_log_id_seq OWNER TO postgres;

--
-- Name: recommendation_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recommendation_log_id_seq OWNED BY public.recommendation_log.id;


--
-- Name: recommendation_results; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recommendation_results (
    id integer NOT NULL,
    user_id integer,
    recommended_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    investment_category character varying(100),
    rank integer,
    compatibility_percentage double precision,
    average_return double precision,
    average_risk double precision
);


ALTER TABLE public.recommendation_results OWNER TO postgres;

--
-- Name: recommendation_results_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recommendation_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recommendation_results_id_seq OWNER TO postgres;

--
-- Name: recommendation_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recommendation_results_id_seq OWNED BY public.recommendation_results.id;


--
-- Name: services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.services (
    service_id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    price numeric(12,2) NOT NULL
);


ALTER TABLE public.services OWNER TO postgres;

--
-- Name: services_service_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.services_service_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.services_service_id_seq OWNER TO postgres;

--
-- Name: services_service_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.services_service_id_seq OWNED BY public.services.service_id;


--
-- Name: user_services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_services (
    id integer NOT NULL,
    user_id integer,
    service_id integer,
    used_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_services OWNER TO postgres;

--
-- Name: user_services_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_services_id_seq OWNER TO postgres;

--
-- Name: user_services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_services_id_seq OWNED BY public.user_services.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    full_name character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    password_hash character varying(255),
    balance numeric(12,2) DEFAULT 0.00,
    role character varying(10) DEFAULT 'user'::character varying,
    create_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    phone character(10),
    address character varying(100),
    avatar text
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_user_id_seq OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- Name: wallet_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wallet_transactions (
    transaction_id integer NOT NULL,
    user_id integer,
    amount numeric(12,2) NOT NULL,
    transaction_type character varying(20),
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT wallet_transactions_transaction_type_check CHECK (((transaction_type)::text = ANY ((ARRAY['deposit'::character varying, 'usage'::character varying])::text[])))
);


ALTER TABLE public.wallet_transactions OWNER TO postgres;

--
-- Name: wallet_transactions_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.wallet_transactions_transaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wallet_transactions_transaction_id_seq OWNER TO postgres;

--
-- Name: wallet_transactions_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.wallet_transactions_transaction_id_seq OWNED BY public.wallet_transactions.transaction_id;


--
-- Name: deposits id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deposits ALTER COLUMN id SET DEFAULT nextval('public.deposits_id_seq'::regclass);


--
-- Name: notification id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification ALTER COLUMN id SET DEFAULT nextval('public.notification_id_seq'::regclass);


--
-- Name: recommendation_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recommendation_log ALTER COLUMN id SET DEFAULT nextval('public.recommendation_log_id_seq'::regclass);


--
-- Name: recommendation_results id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recommendation_results ALTER COLUMN id SET DEFAULT nextval('public.recommendation_results_id_seq'::regclass);


--
-- Name: services service_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services ALTER COLUMN service_id SET DEFAULT nextval('public.services_service_id_seq'::regclass);


--
-- Name: user_services id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_services ALTER COLUMN id SET DEFAULT nextval('public.user_services_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Name: wallet_transactions transaction_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wallet_transactions ALTER COLUMN transaction_id SET DEFAULT nextval('public.wallet_transactions_transaction_id_seq'::regclass);


--
-- Data for Name: deposits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.deposits (id, user_id, amount, method, status, created_at) FROM stdin;
\.


--
-- Data for Name: notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification (id, email_user, title, message, is_read, create_at) FROM stdin;
1	iamrocky0405@gmail.com	abc	abc	f	2025-08-06 19:33:22.780003
\.


--
-- Data for Name: recommendation_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recommendation_log (id, user_email, weights_json, investments_json, created_at) FROM stdin;
2	khangvinhhua0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 39.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 12.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 21.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 12.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Bß║Ñt ─æß╗Öng sß║ún", "Trß╗ìng sß╗æ (%)": "53.30%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "8 - 15% (1 n─âm)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh - Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Hß╗úp ─æß╗ông quyß╗ün chß╗ìn", "Trß╗ìng sß╗æ (%)": "24.96%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "-50% ─æß║┐n 200% (1 n─âm)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Rß║Ñt cao"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Alt coin", "Trß╗ìng sß╗æ (%)": "21.74%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "-50% ─æß║┐n 100% (1 n─âm)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Rß║Ñt cao"}]	2025-08-05 15:39:49.553463
3	khangvinhhua0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 33.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 21.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 12.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 18.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 13.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Bß║Ñt ─æß╗Öng sß║ún", "Trß╗ìng sß╗æ (%)": "51.92%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "8 - 15% (1 n─âm)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh - Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Alt coin", "Trß╗ìng sß╗æ (%)": "25.75%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "-50% ─æß║┐n 100% (1 n─âm)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Rß║Ñt cao"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Cß╗ò phiß║┐u kh├┤ng thuß╗Öc top", "Trß╗ìng sß╗æ (%)": "22.33%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "5 - 10% (1 n─âm)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh - cao"}]	2025-08-05 16:26:50.518931
4	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 35.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 12.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 18.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 17.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Alt coin", "Trß╗ìng sß╗æ (%)": "32.30%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "-50% ─æß║┐n 100% (1 n─âm)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Rß║Ñt cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Cß╗ò phiß║┐u kh├┤ng thuß╗Öc top", "Trß╗ìng sß╗æ (%)": "21.21%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "5 - 10% (1 n─âm)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh - cao"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ hß╗ùn hß╗úp c├ón bß║▒ng", "Trß╗ìng sß╗æ (%)": "17.67%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 12% (1 n─âm)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc / eth)", "Trß╗ìng sß╗æ (%)": "15.48%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "-30% ─æß║┐n 50% (1 n─âm)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Hß╗úp ─æß╗ông quyß╗ün chß╗ìn", "Trß╗ìng sß╗æ (%)": "13.34%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "-50% ─æß║┐n 200% (1 n─âm)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Rß║Ñt cao"}]	2025-08-18 16:03:32.53161
5	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 13.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "30.57%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "-90% ─æß║┐n 200% (1 n─âm)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Rß║Ñt cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "22.96%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "-100% ─æß║┐n 300% (1 n─âm)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Rß║Ñt cao"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "17.85%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1 n─âm)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)\\",-40% ─æß║┐n 80% (1 n─âm),cao,tiß╗ün ─æiß╗çn tß╗¡ c├│ tiß╗üm n─âng sinh lß╗¥i cao nh╞░ng gi├í biß║┐n ─æß╗Öng mß║ính. chß╗ë n├¬n ph├ón bß╗ò nhß╗Å trong danh mß╗Ñc.\\"", "Trß╗ìng sß╗æ (%)": "14.33%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Binance, Remitano, ONUS", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": NaN}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "14.29%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1 n─âm)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-18 16:10:06.979328
6	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 13.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "30.57%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "-90% ─æß║┐n 200% (1 n─âm)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Rß║Ñt cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "22.96%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "-100% ─æß║┐n 300% (1 n─âm)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Rß║Ñt cao"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "17.85%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1 n─âm)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)\\",-40% ─æß║┐n 80% (1 n─âm),cao,tiß╗ün ─æiß╗çn tß╗¡ c├│ tiß╗üm n─âng sinh lß╗¥i cao nh╞░ng gi├í biß║┐n ─æß╗Öng mß║ính. chß╗ë n├¬n ph├ón bß╗ò nhß╗Å trong danh mß╗Ñc.\\"", "Trß╗ìng sß╗æ (%)": "14.33%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Binance, Remitano, ONUS", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": NaN}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "14.29%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1 n─âm)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-18 16:11:56.936069
7	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 21.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 12.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 18.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 15.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "56.69%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "-90% ─æß║┐n 200% (1 n─âm)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Rß║Ñt cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "29.96%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "4.5 - 6.5% (1 n─âm)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "13.35%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1 n─âm)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-18 16:12:33.47361
8	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 21.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 12.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 18.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 15.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "56.69%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "-90% ─æß║┐n 200% (1 n─âm)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Rß║Ñt cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "29.96%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "4.5 - 6.5% (1 n─âm)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "13.35%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1 n─âm)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-18 16:15:09.854923
9	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 18.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 15.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "46.38%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "33.92%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "6 - 8% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "19.70%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-18 16:16:10.764151
10	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 18.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 15.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "46.38%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "33.92%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "6 - 8% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "19.70%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-18 16:34:16.257436
11	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 18.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 15.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "46.38%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "33.92%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "6 - 8% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "19.70%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-18 16:34:44.364259
12	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 18.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 15.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "46.38%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "33.92%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "6 - 8% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "19.70%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-18 16:34:56.674263
13	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 18.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 15.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "46.38%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "33.92%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "6 - 8% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "19.70%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-18 16:37:46.219993
14	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 18.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 15.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "46.38%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "33.92%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "6 - 8% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "19.70%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-18 16:38:25.093822
15	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 18.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 15.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "46.38%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "33.92%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "6 - 8% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "19.70%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-18 16:39:36.484396
16	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 18.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 15.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "46.38%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "33.92%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "6 - 8% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "19.70%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-18 16:39:43.358568
17	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 18.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 15.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "46.38%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "33.92%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "6 - 8% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "19.70%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-18 16:39:46.680528
18	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 18.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 15.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "46.38%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "33.92%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "6 - 8% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "19.70%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-18 16:39:53.998058
19	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 18.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 15.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "46.38%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "33.92%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "6 - 8% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "19.70%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-18 16:40:01.80087
20	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 33.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 12.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 25.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 11.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "45.12%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "7 - 10% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "34.00%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "-100% - 300% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Rß║Ñt cao"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "20.88%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "-90% - 200% (1Y)", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Rß║Ñt cao"}]	2025-08-18 16:42:26.930802
21	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 18.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 10.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 23.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 14.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "63.84%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "18.12%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Thß║Ñp", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "18.04%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-18 16:56:53.002407
22	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 33.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 10.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 29.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 19.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "29.73%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Thß║Ñp", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "23.85%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "21.41%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "13.37%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "11.64%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}]	2025-08-19 15:27:11.336529
23	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 33.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 10.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 29.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 19.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "29.73%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Thß║Ñp", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "23.85%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "21.41%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "13.37%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "11.64%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}]	2025-08-19 15:30:29.260773
24	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 38.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 12.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 24.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 12.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "42.71%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "30.90%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "26.39%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-19 15:46:45.720329
25	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 33.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 20.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 12.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 21.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 11.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "40.16%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "31.43%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "28.41%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-19 15:57:05.523992
26	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 15.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "42.35%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "22.07%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "16.63%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "11.27%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "7.68%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}]	2025-08-23 16:29:43.591271
27	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 15.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "42.35%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "22.07%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "16.63%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "11.27%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "7.68%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}]	2025-08-23 16:32:22.531573
28	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 15.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "42.35%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "22.07%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "16.63%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "11.27%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "7.68%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}]	2025-08-23 16:32:52.246496
29	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 15.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "42.35%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "22.07%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "16.63%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "11.27%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "7.68%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}]	2025-08-23 16:33:00.644469
30	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 15.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "42.35%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "22.07%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "16.63%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "11.27%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "7.68%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}]	2025-08-23 16:33:01.871409
31	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 15.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "42.35%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "22.07%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "16.63%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "11.27%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "7.68%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}]	2025-08-23 16:33:03.057771
39	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 27.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 20.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 20.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 14.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "52.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "25.62%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "21.80%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 16:35:18.209813
32	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 15.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "42.35%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "22.07%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "16.63%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "11.27%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "7.68%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}]	2025-08-23 16:33:11.217592
33	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 15.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "42.35%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "22.07%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "16.63%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "11.27%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "7.68%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}]	2025-08-23 16:33:20.850979
34	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 27.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 20.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 20.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 14.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "52.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "25.62%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "21.80%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 16:33:55.255128
35	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 27.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 20.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 20.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 14.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "52.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "25.62%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "21.80%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 16:34:13.721444
36	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 27.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 20.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 20.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 14.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "52.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "25.62%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "21.80%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 16:34:22.472839
37	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 27.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 20.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 20.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 14.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "52.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "25.62%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "21.80%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 16:34:28.79718
38	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 27.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 20.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 20.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 14.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "52.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "25.62%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "21.80%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 16:34:48.605096
40	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 27.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 20.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 20.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 14.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "52.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "25.62%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "21.80%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 16:35:27.851137
41	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 34.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 21.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 12.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 20.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 18.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "51.97%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "34.30%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "13.73%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 17:13:03.227619
42	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 12.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 17.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "45.61%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "30.70%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "10.37%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "7.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "─Éß║ºu t╞░ bß║íc", "Trß╗ìng sß╗æ (%)": "5.74%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Thß║Ñp", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}]	2025-08-23 17:17:26.556361
43	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 18.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "36.45%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "22.80%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "14.91%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "14.26%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "11.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 17:26:04.797423
44	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 18.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "36.45%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "22.80%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "14.91%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "14.26%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "11.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 17:29:08.626953
45	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 18.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "36.45%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "22.80%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "14.91%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "14.26%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "11.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 17:30:14.769583
46	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 18.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "36.45%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "22.80%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "14.91%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "14.26%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "11.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 17:30:51.657011
47	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 18.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "36.45%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "22.80%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "14.91%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "14.26%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "11.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 17:36:05.98912
48	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 18.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "36.45%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "22.80%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "14.91%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "14.26%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "11.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 17:38:00.16759
49	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 18.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "36.45%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "22.80%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "14.91%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "14.26%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "11.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 17:38:20.306438
50	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 18.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "36.45%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "22.80%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "14.91%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "14.26%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "11.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 17:40:16.634422
51	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 18.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "36.45%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "22.80%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "14.91%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "14.26%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "11.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 17:40:59.596204
52	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 18.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "36.45%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "22.80%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "14.91%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "14.26%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "11.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 17:42:33.032622
53	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 17.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "43.18%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "17.30%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "15.27%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "13.67%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "10.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 17:43:31.301801
54	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 17.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "43.18%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "17.30%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "15.27%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "13.67%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "10.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 17:47:02.919301
55	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 17.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "43.18%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "17.30%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "15.27%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "13.67%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "10.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 17:47:14.481927
56	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 17.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "43.18%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "17.30%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "15.27%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "13.67%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "10.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 17:47:22.788356
57	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 17.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "43.18%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "17.30%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "15.27%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "13.67%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "10.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 17:50:29.411097
58	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 17.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "43.18%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "17.30%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "15.27%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "13.67%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "10.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 17:51:00.213143
59	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 17.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "43.18%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "17.30%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "15.27%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "13.67%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "10.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 17:51:23.23583
60	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 17.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "43.18%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "17.30%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "15.27%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "13.67%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "10.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 17:52:27.290728
61	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 17.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "43.18%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "17.30%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "15.27%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "13.67%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "10.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 17:55:39.941306
62	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 17.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "43.18%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "17.30%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "15.27%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "13.67%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "10.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 17:56:02.721094
63	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 17.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "43.18%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "17.30%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "15.27%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "13.67%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "10.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 17:58:23.57114
64	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 37.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 17.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "43.18%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "17.30%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "15.27%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "13.67%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "10.58%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-23 17:59:53.605819
65	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 35.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 17.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "43.89%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "26.68%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "15.34%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "8.26%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "5.83%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-24 16:06:33.27519
66	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 38.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 18.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "31.47%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "29.11%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "15.99%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "15.38%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "8.05%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-24 16:07:27.192902
67	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 38.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 18.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "31.47%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "29.11%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "15.99%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "15.38%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "8.05%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-24 16:22:00.085751
68	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 38.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 18.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "31.47%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "29.11%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "15.99%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "15.38%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "8.05%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-24 16:24:35.430345
69	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 38.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 18.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "31.47%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "29.11%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "15.99%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "15.38%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "8.05%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-24 16:25:12.367695
70	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 38.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 18.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "31.47%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "29.11%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "15.99%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "15.38%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "8.05%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-24 16:28:28.776567
71	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 38.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 18.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "31.47%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "29.11%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "15.99%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "15.38%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "8.05%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-24 16:28:31.65963
72	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 38.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 18.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "31.47%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "29.11%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "15.99%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "15.38%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "8.05%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-24 16:30:03.144349
73	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 38.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 18.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "31.47%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "29.11%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "15.99%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "15.38%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "8.05%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-24 16:30:21.466342
74	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 35.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 17.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "41.33%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "18.49%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "15.40%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "13.65%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "11.13%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-24 16:35:55.814725
75	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 35.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 17.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "41.33%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "18.49%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "15.40%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "13.65%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "11.13%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-24 16:40:07.95168
76	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 35.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 12.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 23.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "35.47%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "20.16%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "17.28%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "14.99%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "12.10%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}]	2025-08-24 16:40:36.074885
77	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 35.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 12.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 23.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "35.47%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "20.16%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "17.28%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "14.99%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "12.10%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}]	2025-08-24 16:41:56.060177
78	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 35.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 12.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 23.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "35.47%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "20.16%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "17.28%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "14.99%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "12.10%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}]	2025-08-24 16:54:52.87367
79	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 35.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 12.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 23.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "32.26%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "25.86%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "18.34%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "12.51%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "11.03%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-24 17:11:44.695887
80	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 35.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 12.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 23.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "35.27%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "20.81%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "18.70%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "14.53%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "10.69%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-24 17:14:24.259972
81	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 35.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 12.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 23.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "35.27%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "20.81%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "18.70%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "14.53%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "10.69%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-24 17:15:23.580487
82	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 35.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 12.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 23.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "35.27%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "20.81%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "18.70%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "14.53%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "10.69%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-24 17:15:28.272585
83	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 35.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 12.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 23.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "35.27%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "20.81%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "18.70%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "14.53%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "10.69%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-24 17:16:06.298046
84	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 35.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 12.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 23.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "35.27%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "20.81%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "18.70%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "14.53%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "10.69%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-24 17:16:31.857985
85	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 35.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 12.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 23.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "35.27%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "20.81%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "18.70%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "14.53%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "10.69%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-24 17:20:07.142222
86	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 36.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 20.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 18.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 13.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "47.93%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "31.30%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "20.77%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-24 17:20:43.778954
87	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 33.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 20.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 13.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 16.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "34.94%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "20.78%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "19.49%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "15.75%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "9.04%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-24 17:22:26.491143
88	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 23.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 14.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "40.72%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "30.75%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "28.53%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-24 17:24:56.478438
89	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 26.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 18.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 19.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "36.39%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "24.26%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "14.73%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "12.61%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "12.01%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-24 17:25:31.63824
90	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 26.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 18.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 19.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "36.39%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "24.26%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "14.73%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "12.61%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "12.01%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-24 17:28:48.796283
91	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 28.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 12.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 17.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "28.95%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Crypto (btc/eth)", "Trß╗ìng sß╗æ (%)": "20.69%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "20.54%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "15.62%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "14.20%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-24 17:29:12.473345
92	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 33.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 18.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "31.26%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "29.36%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "14.43%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "13.78%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "11.17%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-08-24 17:31:53.799968
93	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 30.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 21.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 12.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 18.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 18.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "─Éß║ºu t╞░ v├áng", "Trß╗ìng sß╗æ (%)": "28.22%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Thß║Ñp", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Hß╗úp ─æß╗ông t╞░╞íng lai (ph├íi sinh)", "Trß╗ìng sß╗æ (%)": "22.43%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "─Éß║ºu t╞░ bß║íc", "Trß╗ìng sß╗æ (%)": "22.20%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Thß║Ñp", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ tr├íi phiß║┐u", "Trß╗ìng sß╗æ (%)": "13.89%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "13.26%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-09-03 20:17:26.279457
94	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 27.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 19.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 18.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 12.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 22.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "─Éß║ºu t╞░ bß║íc", "Trß╗ìng sß╗æ (%)": "45.76%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Thß║Ñp", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "─Éß║ºu t╞░ v├áng", "Trß╗ìng sß╗æ (%)": "28.70%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Thß║Ñp", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Cß╗ò phiß║┐u", "Trß╗ìng sß╗æ (%)": "13.88%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Thß║Ñp", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Chß╗⌐ng quyß╗ün c├│ bß║úo ─æß║úm (cw)", "Trß╗ìng sß╗æ (%)": "9.84%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Altcoin", "Trß╗ìng sß╗æ (%)": "1.82%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Cao", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Cao"}]	2025-09-04 14:35:22.57647
95	iamrocky0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 34.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 21.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 12.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 17.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 20.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "─Éß║ºu t╞░ v├áng", "Trß╗ìng sß╗æ (%)": "35.52%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Thß║Ñp", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "Hß╗úp ─æß╗ông t╞░╞íng lai (ph├íi sinh)", "Trß╗ìng sß╗æ (%)": "19.74%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "─Éß║ºu t╞░ bß║íc", "Trß╗ìng sß╗æ (%)": "19.08%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Thß║Ñp", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "14.74%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "10.92%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}]	2025-09-04 14:47:08.866897
96	khangvinhhua0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 32.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 18.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 15.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 17.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "─Éß║ºu t╞░ bß║íc", "Trß╗ìng sß╗æ (%)": "33.52%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Thß║Ñp", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "─Éß║ºu t╞░ v├áng", "Trß╗ìng sß╗æ (%)": "23.53%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Thß║Ñp", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "18.29%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Hß╗úp ─æß╗ông t╞░╞íng lai (ph├íi sinh)", "Trß╗ìng sß╗æ (%)": "15.83%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Gß╗¡i ng├ón h├áng", "Trß╗ìng sß╗æ (%)": "8.83%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-09-06 14:39:07.501745
97	khangvinhhua0405@gmail.com	[{"Ti├¬u ch├¡": "Lß╗úi nhuß║¡n kß╗│ vß╗ìng", "Trß╗ìng sß╗æ": 29.0}, {"Ti├¬u ch├¡": "Rß╗ºi ro", "Trß╗ìng sß╗æ": 16.0}, {"Ti├¬u ch├¡": "Thanh khoß║ún", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Thß╗¥i gian ─æß║ºu t╞░", "Trß╗ìng sß╗æ": 14.0}, {"Ti├¬u ch├¡": "Chi ph├¡", "Trß╗ìng sß╗æ": 11.0}, {"Ti├¬u ch├¡": "T├¡nh ß╗òn ─æß╗ïnh d├▓ng tiß╗ün", "Trß╗ìng sß╗æ": 20.0}, {"Ti├¬u ch├¡": "─Éa dß║íng h├│a", "Trß╗ìng sß╗æ": 16.0}]	[{"STT": 1, "Danh mß╗Ñc ─æß║ºu t╞░": "─Éß║ºu t╞░ v├áng", "Trß╗ìng sß╗æ (%)": "27.73%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Thß║Ñp", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 2, "Danh mß╗Ñc ─æß║ºu t╞░": "─Éß║ºu t╞░ bß║íc", "Trß╗ìng sß╗æ (%)": "24.88%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Thß║Ñp", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 3, "Danh mß╗Ñc ─æß║ºu t╞░": "Hß╗úp ─æß╗ông t╞░╞íng lai (ph├íi sinh)", "Trß╗ìng sß╗æ (%)": "16.28%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 4, "Danh mß╗Ñc ─æß║ºu t╞░": "Tr├íi phiß║┐u doanh nghiß╗çp", "Trß╗ìng sß╗æ (%)": "16.00%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Thß║Ñp"}, {"STT": 5, "Danh mß╗Ñc ─æß║ºu t╞░": "Quß╗╣ c├ón bß║▒ng (hß╗ùn hß╗úp)", "Trß╗ìng sß╗æ (%)": "15.11%", "Lß╗úi nhuß║¡n ╞░ß╗¢c t├¡nh": "Trung b├¼nh", "Rß╗ºi ro ╞░ß╗¢c t├¡nh": "Trung b├¼nh"}]	2025-09-06 14:44:36.581609
\.


--
-- Data for Name: recommendation_results; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recommendation_results (id, user_id, recommended_at, investment_category, rank, compatibility_percentage, average_return, average_risk) FROM stdin;
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.services (service_id, name, description, price) FROM stdin;
\.


--
-- Data for Name: user_services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_services (id, user_id, service_id, used_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (user_id, full_name, email, password_hash, balance, role, create_at, phone, address, avatar) FROM stdin;
4	Rocky Hß╗⌐a	khangvinhhua0405@gmail.com	scrypt:32768:8:1$ng6ekVSs13uj8AXO$5c4c9b95a41060ac12fa9f1f2268b172f36696b55562ec41bdb60863124acdc55f455a29f865fa7e7f15f364aeecf3a937e3ffcbb295938e4b738f984c8cf9ee	0.00	user	2025-08-03 16:15:50.772636	0382973508	Xu├ón Thß╗¢i S╞ín, H├│c M├┤n, Hß╗ô Ch├¡ Minh	static/uploads/admin.png
1	Admin	iamrocky0405@gmail.com	scrypt:32768:8:1$U8uw09EnVCzP51gu$b6cc788e8c56744c942be8aae9807538e1399876572e27abcd605c300e40115eaeea69fc6575c390b13575baa52f71b3bd914aa273511b61320453637ac764e0	1000000.00	admin	2025-06-23 18:17:58.14575	0382973508	Xu├ón Thß╗¢i S╞ín, Hß╗ô Ch├¡ Minh	static/uploads/admin.png
2	Hß╗⌐a V─⌐nh Khang	huavinhnam2005@gmail.com	scrypt:32768:8:1$JzUBhdWEtz3OTKFU$e44517791f359a3392289b849cc62f6ff0a1258770f0978f8e3bb36aa579603259399a4ef95d617774c825e1164155f0df6d6e1185aca1ca4c35cb31dcd85237	150000.00	user	2025-06-23 18:30:06.833403	0382973508	Xu├ón Thß╗¢i S╞ín, Hß╗ô Ch├¡ Minh	static/css/assets/Khang.jpg
\.


--
-- Data for Name: wallet_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wallet_transactions (transaction_id, user_id, amount, transaction_type, description, created_at) FROM stdin;
\.


--
-- Name: deposits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.deposits_id_seq', 1, false);


--
-- Name: notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notification_id_seq', 1, false);


--
-- Name: recommendation_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recommendation_log_id_seq', 97, true);


--
-- Name: recommendation_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recommendation_results_id_seq', 1, false);


--
-- Name: services_service_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.services_service_id_seq', 1, false);


--
-- Name: user_services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_services_id_seq', 1, false);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_user_id_seq', 4, true);


--
-- Name: wallet_transactions_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.wallet_transactions_transaction_id_seq', 1, false);


--
-- Name: deposits deposits_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deposits
    ADD CONSTRAINT deposits_pkey PRIMARY KEY (id);


--
-- Name: users email_constraint; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT email_constraint UNIQUE (email);


--
-- Name: notification notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (id);


--
-- Name: recommendation_log recommendation_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recommendation_log
    ADD CONSTRAINT recommendation_log_pkey PRIMARY KEY (id);


--
-- Name: recommendation_results recommendation_results_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recommendation_results
    ADD CONSTRAINT recommendation_results_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (service_id);


--
-- Name: user_services user_services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_services
    ADD CONSTRAINT user_services_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: wallet_transactions wallet_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wallet_transactions
    ADD CONSTRAINT wallet_transactions_pkey PRIMARY KEY (transaction_id);


--
-- Name: deposits deposits_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deposits
    ADD CONSTRAINT deposits_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: notification fk_email_user_users; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT fk_email_user_users FOREIGN KEY (email_user) REFERENCES public.users(email);


--
-- Name: recommendation_log fk_user_email; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recommendation_log
    ADD CONSTRAINT fk_user_email FOREIGN KEY (user_email) REFERENCES public.users(email) ON DELETE CASCADE;


--
-- Name: recommendation_results recommendation_results_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recommendation_results
    ADD CONSTRAINT recommendation_results_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: user_services user_services_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_services
    ADD CONSTRAINT user_services_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(service_id) ON DELETE CASCADE;


--
-- Name: user_services user_services_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_services
    ADD CONSTRAINT user_services_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: wallet_transactions wallet_transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wallet_transactions
    ADD CONSTRAINT wallet_transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

