﻿import os
import numpy as np

# Import class
from Algorithm_Investment import Algorithm_Investment
from Criteria_Manager import CriteriaManager
from Individual_Generator import IndividualGenerator
from Algorithm_Parameters import AlgorithmParameters
from Fitness_Investment import Fitness_Function_Investment
from Caculate_Fitness_Individual_Generator import Caculate_Fitness_Individual_Generator
from algorithms.Hybrid_Algorithm_max import HybridCOA_MVO  
from Weights_Result import display_ahp_results
from Display_Investments import DisplayInvestmentsByCategory

def main():
    # Xác định thư mục gốc chứa file database
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    DATABASE_DIR = os.path.join(BASE_DIR, "database")

    # Khởi tạo cấu hình thuật toán
    config = AlgorithmParameters()
    parameters = config.get_parameters()
    pop_size = parameters["pop_size"]
    bounds = parameters["bounds"]
    max_iter = parameters["max_iter"]
    switch_iter = parameters["switch_iter"]
    data = parameters["data"]

    # Khởi tạo đối tượng quản lý tiêu chí đầu tư
    criteria_manager = CriteriaManager(
        data_file=os.path.join(DATABASE_DIR, "criteria_data.csv"),
        criteria_file=os.path.join(DATABASE_DIR, "criteria_values.csv"),
        file_path=os.path.join(DATABASE_DIR, "criteria_and_risk_investment.csv")
    )
    
    # Tính toán trọng số AHP
    weights = criteria_manager.compute_weights()
    criteria_manager.load_criteria_values()
    criteria_manager.load_investment_data()

    # Thiết lập tham số cho thuật toán tối ưu hóa
    algo_parameters = Algorithm_Investment(
        positive_indices=[0, 2, 5],
        negative_indices=[1, 4],
        diversification_index=6,
        investment_time_index=3
    )

    # Xác định số biến dựa trên trọng số
    sorted_indices = np.argsort(weights)[-3:]
    n_bien = 10 if 6 in sorted_indices else 6

    # Khởi tạo quần thể cá thể
    individual_generator = IndividualGenerator(criteria_manager=criteria_manager, pop_size=pop_size)
    population = individual_generator.generate_population()

    # Tạo hàm fitness cho đầu tư
    fitness_function_investment = Fitness_Function_Investment(criteria_manager, algo_parameters)
    fitness_investment = np.array([
        fitness_function_investment.fitness_function(i)
        for i in range(criteria_manager.criteria_values.shape[0])
    ])

    # Tính toán độ thích nghi cho từng cá thể trong quần thể
    fitness = np.abs(Caculate_Fitness_Individual_Generator.calculate_fitness(fitness_investment, population))

    # Khởi tạo thuật toán lai Hybrid COA-MVO
    hybrid_coa_mvo = HybridCOA_MVO(
    population,
    fitness,
    bounds,
    max_iter,
    switch_iter,
    fitness_investment,
    replacement_map_file=os.path.join(DATABASE_DIR,"replacement_map1.csv"),
    categories_file=os.path.join(DATABASE_DIR,"categories.csv"),
    criteria_manager=criteria_manager,
    file_path=DATABASE_DIR
    )

    best_solution_investment = hybrid_coa_mvo.run()

    # Hiển thị kết quả phân loại đầu tư
    display = DisplayInvestmentsByCategory(
    criteria_manager=criteria_manager,
    categories_file=os.path.join(DATABASE_DIR, "categories.csv"),
    file_path=DATABASE_DIR
    )

    # Hiển thị kết quả AHP và danh mục tối ưu nhất
    display_ahp_results(weights)
    classified_investments, xi_investments = display.classify_investments(best_solution_investment)
    display.display_investments_by_category(classified_investments, best_solution_investment)

    return xi_investments

if __name__ == "__main__":
    main()

