# Flask và các tiện ích liên quan
from flask import Flask, render_template, request, redirect, url_for, Response, session, flash, send_file, abort

# Bảo mật và xử lý file
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash

# Xử lý dữ liệu
import pandas as pd
import json
import csv
import random 

# Thời gian và hệ thống
from datetime import datetime
from pathlib import Path
import io,os
from werkzeug.utils import secure_filename

# Môi trường
from dotenv import load_dotenv

# Email
import smtplib
import ssl
from email.message import EmailMessage

# Tạo ảnh, biểu đồ
import matplotlib.pyplot as plt
import io
import base64
import qrcode

# Xử lý Word
import docx

# Module nội bộ
from main import main
from Display_Investments import DisplayInvestmentsByCategory
from db import get_conn, put_conn


from db import get_conn, put_conn

# === Cấu hình thư mục ===
user_wallets = {}
pending_topups = []
BASE_DIR = Path(__file__).resolve().parent
DATABASE_DIR = BASE_DIR / "database"
DATA_CUSTOMER_DIR = BASE_DIR / "data_customer"
NOTIFICATION_FILE = DATABASE_DIR / "notification.json"
DOCS_DIR = BASE_DIR / "docs"
UPLOAD_DIR = BASE_DIR / 'Website' / 'static' / 'uploads'
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
DATA_CUSTOMER_DIR.mkdir(parents=True, exist_ok=True)
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp', 'svg', 'tiff'}

# === Khởi tạo Flask App ===
load_dotenv()
app = Flask(__name__, template_folder="Website/templates", static_folder="Website/static")
app.secret_key = os.getenv('SERECT_KEY')

criteria = [
    "Lợi nhuận kỳ vọng", "Rủi ro", "Thanh khoản", "Thời gian đầu tư",
    "Chi phí", "Tính ổn định dòng tiền", "Đa dạng hóa"
]

# === Tiện ích ===

def save_notifications(notifications):
    with NOTIFICATION_FILE.open('w', encoding='utf-8') as f:
        json.dump(notifications, f, ensure_ascii=False, indent=2)

def add_notification(message, user='admin'):
    noti = {
        "id": int(datetime.now().timestamp()),
        "user": user,
        "message": message,
        "time": datetime.now().strftime("%d/%m/%Y %H:%M"),
        "read": False
    }
    notifications = load_notifications()
    notifications.insert(0, noti)  # thêm vào đầu danh sách
    save_notifications(notifications)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def read_csv(file_path, required_columns=None):
    file_path = DATABASE_DIR / file_path
    if not file_path.exists():
        return []
    try:
        df = pd.read_csv(file_path, encoding="utf-8-sig")
        if required_columns and not all(col in df.columns for col in required_columns):
            return []
        return df.to_dict(orient="records")
    except Exception:
        return []

def read_survey_from_docx(file_path):
    if not file_path.exists():
        return []
    
    doc = docx.Document(file_path)
    questions, current_question = [], None

    for para in doc.paragraphs:
        line = para.text.strip()
        if not line:
            continue
        if line.startswith("Câu hỏi"):
            if current_question and current_question["options"]:
                questions.append(current_question)
            current_question = {"question": line, "options": []}
        elif current_question and ":" not in line:
            current_question["options"].append({"text": line, "weights": {}})
        elif current_question and ":" in line and current_question["options"]:
            criterion, value = line.split(":", 1)
            try:
                current_question["options"][-1]["weights"][criterion.strip()] = float(value.strip())
            except ValueError:
                pass

    if current_question and current_question["options"]:
        questions.append(current_question)

    return questions

survey_files = ["survey1.docx", "survey2.docx", "survey3.docx"]
surveys = [read_survey_from_docx(DOCS_DIR / file) for file in survey_files]

@app.context_processor
def inject_user():
    email = session.get('user') 
    full_name = session.get('full_name')
    role = session.get('role')
    avatar_url = session.get('avatar')
    phone = session.get('phone')

    notifications = []
    noti_count = 0
    if email:
        notifications = [
            n for n in load_notifications()
            if n['email_user'] == email or role == 'admin'
        ]
        noti_count = sum(1 for n in notifications if not n['is_read'])

    return {
        'email': email,
        'full_name': full_name,
        'avatar_url': avatar_url,
        'logged_in': bool(email),
        'new_notifications': noti_count,
        'notifications': notifications,
        'is_admin': role == 'admin' if role else False,
        'cache_buster': random.randint(0, 999999),
        'phone': phone
    }

def load_notifications():
    conn = get_conn()
    try:
        cur = conn.cursor()
        cur.execute("SELECT id, email_user, title, message, is_read, create_at FROM notification ORDER BY create_at DESC")
        rows = cur.fetchall()
        notifications = [
            {
                "id": row[0],
                "email_user": row[1],
                "title": row[2],
                "message": row[3],
                "is_read": row[4],
                "time": row[5].strftime("%d/%m/%Y %H:%M") if isinstance(row[5], datetime) else row[5]
            } for row in rows
        ]
        return notifications
    finally:
        conn.close()

# === Các route chính ===
@app.route('/')
def home():
    return render_template('home.html', logged_in='user' in session, username=session.get('full_name'), avatar_url=session.get('avatar'))

@app.route('/wallet')
def wallet():
    if 'user' not in session:
        flash("Bạn cần đăng nhập để truy cập ví.", "error")
        return redirect(url_for('login'))

    email = session['user']  

    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT balance FROM users WHERE email = %s", (email,))
    row = cur.fetchone()
    cur.close()
    put_conn(conn)

    balance = row[0] if row else 0

    full_name = session.get('full_name', '')
    return render_template(
        'wallet.html',
        balance=balance,
        username=full_name, 
        avatar_url=session.get('avatar'),
        logged_in=True
    )

@app.route('/notifications')
def notifications():
    if 'user' not in session:
        return redirect(url_for('login'))

    username = session['user']
    is_admin = username == 'admin'

    all_notifications = load_notifications()
    user_notifications = [n for n in all_notifications if is_admin or n['user'] == username]

    unread_count = sum(1 for n in user_notifications if not n['read'])

    return render_template(
        'notifications.html',
        notifications=user_notifications,
        new_notifications=unread_count,
        is_admin=is_admin,
        username=username,
        avatar_url=session.get('avatar')
    )

@app.route('/notifications/mark-read/<int:noti_id>', methods=['POST'])
def mark_notification_read(noti_id):
    conn = get_conn()
    try:
        cur = conn.cursor()
        cur.execute("UPDATE notification SET is_read = TRUE WHERE id = %s", (noti_id,))
        conn.commit()
        flash("Đã đánh dấu là đã đọc.", "success")
    finally:
        conn.close()

    return redirect(request.referrer or url_for('home'))

@app.route('/notifications/delete/<int:noti_id>', methods=['POST'])
def delete_notification(noti_id):
    conn = get_conn()
    try:
        cur = conn.cursor()
        cur.execute("DELETE FROM notification WHERE id = %s", (noti_id,))
        conn.commit()
        flash("Đã xóa thông báo.", "success")
    finally:
        conn.close()

    return redirect(request.referrer or url_for('home'))



@app.route('/register-service', methods=['GET', 'POST'])
def register_service():
    if 'user' not in session:
        flash("Bạn cần đăng nhập để đăng ký dịch vụ.", "error")
        return redirect(url_for('login'))

    if request.method == 'POST':
        package = request.form.get('package')
        note = ""  # Nếu sau này bạn cho người dùng ghi chú

        user = session.get('user')  # Tài khoản đang đăng nhập

        # Ghi log hoặc lưu vào CSDL tùy nhu cầu
        file_path = DATABASE_DIR / 'service_registrations.csv'
        if not file_path.exists():
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write("user,package,note\n")

        with open(file_path, 'a', encoding='utf-8') as f:
            f.write(f"{user},{package},{note}\n")

        flash(f"Bạn đã đăng ký gói '{package}' thành công!", "success")
        return redirect(url_for('register_service'))

    return render_template(
        'register_service.html',
        logged_in='user' in session,
        username=session.get('full_name'),
        avatar_url=session.get('avatar')
    )

@app.route('/generate_qr/<wallet>/<int:amount>')
def generate_qr(wallet, amount):
    if wallet == "momo":
        momo_deeplink = f"https://nhantien.momo.vn/0382973508?amount={amount}&comment=NAP_{amount}"
        qr = qrcode.make(momo_deeplink)

    elif wallet == "vnpay":
        vnpay_url = f"https://sandbox.vnpayment.vn/paymentv2/vpcpay.html?amount={amount}&acc=SMARTVEST"
        qr = qrcode.make(vnpay_url)

    else:
        return abort(400, description="Ví chưa hỗ trợ")

    # Xuất mã QR dưới dạng ảnh PNG
    buf = io.BytesIO()
    qr.save(buf, format='PNG')
    buf.seek(0)
    return send_file(buf, mimetype='image/png')

@app.route('/deposit-money', methods=['GET', 'POST'])
def deposit_money():
    if 'user' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        try:
            amount = int(request.form.get('amount', 0))
            email = session['user']

            if amount <= 0:
                return redirect(url_for('deposit_money'))

            conn = get_conn()
            cur = conn.cursor()

            print("Email session:", email)
            cur.execute("SELECT balance FROM users WHERE email = %s", (email,))
            print("Before:", cur.fetchone())

            cur.execute("UPDATE users SET balance = balance + %s WHERE email = %s", (amount, email))
            conn.commit()

            cur.execute("SELECT balance FROM users WHERE email = %s", (email,))
            print("After:", cur.fetchone())

            cur.close()
            put_conn(conn)

            return redirect(url_for('wallet'))

        except Exception as e:
            print("Error:", e)
            return redirect(url_for('deposit_money'))

    return render_template(
        'deposit_money.html',
        username=session.get('full_name', ''),
        avatar_url=session.get('avatar'),
        logged_in=True
    )


@app.route('/process_deposit/<int:noti_id>', methods=['POST'])
def process_deposit(noti_id):
    if 'user' not in session or session['user'] != 'admin':
        flash("Bạn không có quyền thực hiện hành động này", "danger")
        return redirect(url_for('home'))

    action = request.form.get('action')  # 'approve' hoặc 'reject'
    notifications = load_notifications()
    for noti in notifications:
        if noti['id'] == noti_id:
            if noti.get('processed'):
                flash("Thông báo này đã được xử lý rồi.", "warning")
                break
            noti['read'] = True
            noti['processed'] = True
            if action == 'approve':
                username = noti.get('user')
                amount_str = ''.join(filter(str.isdigit, noti['message']))
                try:
                    amount = int(amount_str)
                    user_wallets[username] = user_wallets.get(username, 0) + amount
                    flash(f"✅ Đã duyệt {amount:,} VND cho {username}", "success")
                except Exception:
                    flash("Không thể đọc số tiền từ thông báo.", "error")
            else:
                flash("⛔ Yêu cầu nạp đã bị từ chối.", "info")
            break
    else:
        flash("❌ Không tìm thấy thông báo.", "error")

    save_notifications(notifications)
    return redirect(url_for('home'))

@app.route('/admin/topups')
def admin_topups():
    if session.get('user') != 'admin':
        return "Bạn không có quyền truy cập!", 403
    return render_template('admin_topups.html', topups=pending_topups)

@app.route('/admin/approve/<int:index>')
def approve_topup(index):
    if session.get('user') != 'admin':
        return "Bạn không có quyền duyệt!", 403
    try:
        topup = pending_topups[index]
        if topup['status'] == 'pending':
            username = topup['username']
            user_wallets[username] = user_wallets.get(username, 0) + topup['amount']
            topup['status'] = 'approved'
            flash(f"✔ Đã duyệt nạp {topup['amount']} VND cho {username}", "success")
    except IndexError:
        flash("❌ Không tìm thấy yêu cầu nạp", "error")
    return redirect(url_for('admin_topups'))

@app.route('/profile')
def profile():
    if 'user' not in session:
        return redirect(url_for('login'))

    conn = get_conn()
    try:
        cur = conn.cursor()
        cur.execute("SELECT full_name, email, phone, address, avatar FROM users WHERE email = %s", (session['user'],))
        row = cur.fetchone()
        cur.close()
    finally:
        put_conn(conn)

    if row:
        full_name, email, phone, address, avatar = row
        return render_template(
            'profile.html',
            full_name=full_name,
            email=email,
            phone=phone,
            address=address,
            avatar=avatar, 
            logged_in=True,
            username=full_name
        )
    else:
        flash("Không tìm thấy thông tin người dùng!", "error")
        return redirect(url_for('login'))

from werkzeug.utils import secure_filename
from pathlib import Path

@app.route('/upload_avatar', methods=['POST'])
def upload_avatar():
    file = request.files.get('avatar')
    if not file or file.filename == '':
        flash('Không có tệp được chọn')
        return redirect(url_for('profile'))

    if allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file_path = UPLOAD_DIR / filename  # pathlib đảm bảo chuẩn
        file.save(str(file_path))

        # Chuẩn hóa đường dẫn để lưu vào DB
        avatar_path = f'static/uploads/{filename}'

        # Cập nhật vào DB
        username = session.get('user')
        conn = get_conn()
        try:
            cur = conn.cursor()
            cur.execute("UPDATE users SET avatar = %s WHERE email = %s", (avatar_path, username))
            conn.commit()
            cur.close()
        finally:
            put_conn(conn)

        flash('Tải ảnh thành công')
    else:
        flash('Tệp không hợp lệ')

    return redirect(url_for('profile'))



@app.route('/update_profile', methods=['POST'])
def update_profile():
    if 'user' not in session:
        return redirect(url_for('login'))

    email = session['user']
    full_name = request.form.get('full_name')
    phone = request.form.get('phone')
    address = request.form.get('address')

    avatar = None
    file = request.files.get('avatar')
    if file and allowed_file(file.filename):
        original_filename = secure_filename(file.filename.strip())
        file_path = UPLOAD_DIR / original_filename
        file.save(str(file_path))

        # Tạo đường dẫn tương đối để lưu vào DB
        avatar_path = Path('static/uploads') / original_filename
        avatar = str(avatar_path).replace("\\", "/")  

    # Cập nhật vào CSDL
    conn = get_conn()
    try:
        cur = conn.cursor()

        if avatar:
            cur.execute("""
                UPDATE users 
                SET full_name = %s, phone = %s, address = %s, avatar = %s 
                WHERE email = %s
            """, (full_name, phone, address, avatar, email))
        else:
            cur.execute("""
                UPDATE users 
                SET full_name = %s, phone = %s, address = %s 
                WHERE email = %s
            """, (full_name, phone, address, email))

        conn.commit()
        cur.close()
    finally:
        put_conn(conn)

    flash('Cập nhật thông tin thành công.')
    return redirect(url_for('profile'))


@app.route('/survey', methods=['GET', 'POST'])
def survey():
    if 'user' not in session:
        return redirect(url_for('login', next=request.url))

    if request.method == 'POST':
        answers = request.form.to_dict()
        survey_index = int(answers['survey_index'])
        selected_survey = surveys[survey_index]

        total_weights = {criterion: 10 for criterion in criteria}
        total_weights["Rủi ro"] = 8
        total_weights["Chi phí"] = 8

        for i, question in enumerate(selected_survey):
            selected_option = answers.get(f'q{i}', '')
            for option in question['options']:
                if option['text'] == selected_option:
                    for criterion, weight in option['weights'].items():
                        if criterion not in total_weights:
                            total_weights[criterion] = 0
                        total_weights[criterion] += max(weight, 1)

        file_path = DATA_CUSTOMER_DIR / "weights.csv"
        with file_path.open("w", encoding="utf-8-sig", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["Tiêu chí", "Trọng số"])
            for criterion in criteria:
                writer.writerow([criterion, total_weights.get(criterion, 0)])

        xi_investments = main()
        session['xi_investments'] = xi_investments
        return redirect(url_for('results'))

    survey_index = random.randint(0, len(surveys) - 1)
    selected_survey = surveys[survey_index]
    return render_template('survey.html', questions=selected_survey, survey_index=survey_index)

@app.route('/results')
def results():
    if 'user' not in session:
        return redirect(url_for('login', next=request.url))

    ahp_data = read_csv("ahp_results.csv", ["Criteria", "Weight", "Rank"])
    investment_data = read_csv("investment_results.csv", ["STT", "Danh mục đầu tư"])

    weights_data = []
    weights_file = DATA_CUSTOMER_DIR / "weights.csv"
    if weights_file.exists():
        try:
            df = pd.read_csv(weights_file, encoding="utf-8-sig")
            weights_data = df.to_dict(orient="records")
        except Exception:
            pass

    pie_chart_base64 = create_pie_chart()
    xi_investments = session.get('xi_investments', [])
    pie_chart_expected_return_and_risk = create_risk_return_chart(
        criteria_file=DATABASE_DIR / "criteria_values.csv", 
        names_file=DATABASE_DIR / "criteria_and_risk_investment.csv",
        xi_investments=xi_investments
    )

    try:
        user_email = session['user']
        conn = get_conn()
        cur = conn.cursor()

        weights_json = json.dumps(weights_data, ensure_ascii=False)
        investments_json = json.dumps(investment_data, ensure_ascii=False)

        cur.execute("""
            INSERT INTO recommendation_log (user_email, weights_json, investments_json)
            VALUES (%s, %s, %s)
        """, (user_email, weights_json, investments_json))

        conn.commit()
        cur.close()
        put_conn(conn)
    except Exception as e:
        print("Lỗi khi lưu lịch sử:", e)

    return render_template('result.html', weights_data=weights_data, ahp_data=ahp_data, investment_data=investment_data, pie_chart_base64=pie_chart_base64, pie_chart_expected_return_and_risk=pie_chart_expected_return_and_risk)

from datetime import datetime

@app.route('/history')
def recommendation_history():
    if 'user' not in session:
        return redirect(url_for('login'))

    conn = get_conn()
    try:
        cur = conn.cursor()
        cur.execute("SELECT id, weights_json, investments_json, created_at FROM recommendation_log WHERE user_email = %s ORDER BY created_at DESC", (session['user'],))
        rows = cur.fetchall()
        history = []
        for row in rows:
            log_id = row[0]

            weights_load = json.loads(row[1])
            sorted_weights = sorted(weights_load, key=lambda x: x["Trọng số"], reverse=True)

            investments = json.loads(row[2])
            created_at_raw = row[3]

            if isinstance(created_at_raw, str):
                created_at = datetime.strptime(created_at_raw, "%Y-%m-%d %H:%M:%S.%f")
            else:
                created_at = created_at_raw

            history.append({
                'id': log_id,
                'weights': sorted_weights,
                'investments': investments,
                'created_at': created_at
            })

        cur.close()
    finally:
        put_conn(conn)

    return render_template("recommendation_history.html", history=history, username=session.get('full_name'), avatar_url=session.get('avatar'))


@app.route('/delete_history/<int:log_id>', methods=['POST'])
def delete_history(log_id):
    conn = get_conn()
    try:
        cur = conn.cursor()
        cur.execute("DELETE FROM recommendation_log WHERE id = %s AND user_email = %s", (log_id, session['user']))
        conn.commit()
        cur.close()
    finally:
        put_conn(conn)
    return redirect(url_for('recommendation_history'))


@app.route('/update_weights', methods=['GET', 'POST'])
def update_weights():
    weights_file = DATA_CUSTOMER_DIR / "weights_update.csv"
    if not weights_file.exists():
        # Tạo file mặc định nếu chưa có
        default_data = {
            "population_size": 50,
            "max_iter": 100,
            "dimensions": 5,
            "lower_bound": -1.0,
            "upper_bound": 1.0
        }
        df = pd.DataFrame([default_data])
        df.to_csv(weights_file, index=False, encoding="utf-8-sig")

    # Kiểm tra đăng nhập
    if 'user' not in session:
        return redirect(url_for('login', next=request.url))

    # Kiểm tra quyền admin
    if session.get('role') != 'admin':
        flash("Bạn không có quyền thực hiện thao tác này.", "danger")
        return redirect(url_for('home'))

    if request.method == 'POST':
        # Lấy dữ liệu từ form
        population_size = request.form.get('population_size', type=int, default=50)
        max_iter = request.form.get('max_iter', type=int, default=100)
        dimensions = request.form.get('dimensions', type=int, default=5)
        lower_bound = request.form.get('lower_bound', type=float, default=0.0)
        upper_bound = request.form.get('upper_bound', type=float, default=1.0)

        # Tạo DataFrame chứa cấu hình
        df = pd.DataFrame([{
            "population_size": population_size,
            "max_iter": max_iter,
            "dimensions": dimensions,
            "lower_bound": lower_bound,
            "upper_bound": upper_bound
        }])

        try:
            # Ghi vào file CSV theo chuẩn UTF-8-SIG, ghi đè
            df.to_csv(weights_file, index=False, encoding="utf-8-sig")
            flash("Đã lưu thông số thuật toán thành công!", "success")
        except Exception as e:
            flash(f"Lỗi khi lưu thông số thuật toán: {e}", "danger")

        return redirect(url_for('update_weights'))

    else:
        # Xử lý GET: đọc file cấu hình hiện tại để hiển thị
        try:
            df = pd.read_csv(weights_file)
            config = df.iloc[0].to_dict()
        except Exception:
            # Mặc định nếu chưa có file hoặc lỗi đọc file
            config = {
                "population_size": 50,
                "max_iter": 100,
                "dimensions": 5,
                "lower_bound": 0.0,
                "upper_bound": 1.0
            }

        return render_template('update_weights.html', username=session.get('full_name'), avatar_url=session.get('avatar'),**config)


@app.route('/download_csv')
def download_csv():
    if 'user' not in session:
        return redirect(url_for('login', next=request.url))

    file_path = DATA_CUSTOMER_DIR / "weights.csv"
    if not file_path.exists():
        return "File không tồn tại", 404

    return Response(file_path.read_text(encoding="utf-8-sig"), mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=weights.csv"})

import psycopg2.extras  

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        conn = get_conn()
        try:
            cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
            cur.execute("SELECT user_id, full_name, email, password_hash, role, avatar FROM users WHERE email = %s", (email,))
            user = cur.fetchone()
            cur.close()
        finally:
            put_conn(conn)

        if user:
            # Truy cập theo key thay vì tuple
            if check_password_hash(user['password_hash'], password):
                session['user'] = user['email']
                session['user_id'] = user['user_id']
                session['full_name'] = user['full_name']
                session['role'] = user['role']
                session['avatar'] = user['avatar']
                flash("Đăng nhập thành công!", "success")
                return redirect(url_for('home'))

        flash("Email hoặc mật khẩu không đúng!", "error")
        return render_template('login.html')

    return render_template('login.html')

@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form.get('reset_email')
        if not email:
            flash("Vui lòng nhập email của bạn!", "error")
            return redirect(url_for('forgot_password'))

        conn = get_conn()
        try:
            cur = conn.cursor()
            cur.execute("SELECT 1 FROM users WHERE email = %s", (email,))
            if not cur.fetchone():
                flash("Email không tồn tại trong hệ thống!", "error")
                return redirect(url_for('forgot_password'))
        finally:
            put_conn(conn)

        # Gửi OTP
        otp = send_otp_email(email)
        session['reset_email'] = email
        session['otp'] = otp

        flash('Mã OTP đã được gửi đến email của bạn', 'success')
        return redirect(url_for('verify_otp'))

    return render_template('forgot_password.html')


def send_otp_email(receiver_email):
    otp = str(random.randint(100000, 999999))

    subject = "Mã OTP đặt lại mật khẩu"
    body = f"""\
Xin chào,

Đây là mã OTP của bạn để đặt lại mật khẩu: {otp}

Vui lòng không chia sẻ mã này với bất kỳ ai. Mã sẽ hết hạn sau vài phút.

Trân trọng,
Hệ thống hỗ trợ người dùng
"""

    em = EmailMessage()
    em['From'] = os.getenv('EMAIL_SENDER')
    em['To'] = receiver_email
    em['Subject'] = subject
    em.set_content(body)

    context = ssl.create_default_context()

    with smtplib.SMTP_SSL('smtp.gmail.com', 465, context=context) as smtp:
        smtp.login(os.getenv('EMAIL_SENDER'), os.getenv('EMAIL_PASSWORD'))
        smtp.send_message(em)

    return otp

@app.route('/send_otp', methods=['POST'])
def send_otp():
    email = request.form.get('reset_email')
    
    otp = send_otp_email(email)

    session['reset_email'] = email
    session['otp'] = otp

    flash('Mã OTP đã được gửi đến email của bạn', 'success')
    return redirect(url_for('verify_otp'))

@app.route('/verify_otp', methods=['GET', 'POST'])
def verify_otp():
    if request.method == 'POST':
        user_otp = request.form.get('otp')
        if user_otp == session.get('otp'):
            return redirect(url_for('reset_password'))
        else:
            flash('OTP không đúng, vui lòng thử lại.', 'error')
    
    return render_template('verify_otp.html')


@app.route('/reset_password', methods=['GET', 'POST'])
def reset_password():
    if request.method == 'POST':
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')

        if not new_password or not confirm_password:
            flash("Vui lòng nhập đầy đủ thông tin!", "error")
            return redirect(url_for('reset_password'))

        if new_password != confirm_password:
            flash("Mật khẩu không khớp!", "error")
            return redirect(url_for('reset_password'))

        email = session.get('reset_email')
        if not email:
            flash("Không tìm thấy thông tin người dùng!", "error")
            return redirect(url_for('forgot_password'))

        # Hash mật khẩu mới
        hashed_password = generate_password_hash(new_password)

        # Lưu vào CSDL
        conn = get_conn()
        try:
            cur = conn.cursor()
            cur.execute("UPDATE users SET password_hash = %s WHERE email = %s", (hashed_password, email))
            conn.commit()
            flash("Mật khẩu đã được đặt lại thành công!", "success")
        finally:
            put_conn(conn)

        session.pop('reset_email', None)
        session.pop('otp', None)

        return redirect(url_for('login'))

    return render_template('reset_password.html')


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))

@app.route('/sign-up', methods=['GET', 'POST'])
def sign_up():
    if request.method == 'POST':
        full_name = request.form.get('full_name', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '').strip()
        confirm_password = request.form.get('confirm_password', '').strip()

        # Kiểm tra các trường có bị bỏ trống không
        if not all([full_name, email, password, confirm_password]):
            return render_template('sign_up.html', error="Vui lòng điền đầy đủ tất cả các trường!")

        if password != confirm_password:
            return render_template('sign_up.html', error="Mật khẩu xác nhận không khớp!")

        hashed_pw = generate_password_hash(password)

        conn = get_conn()
        try:
            cur = conn.cursor()
            cur.execute("SELECT 1 FROM users WHERE email = %s", (email,))
            if cur.fetchone():
                return render_template('sign_up.html', error="Email đã được đăng ký!")

            cur.execute("""
                INSERT INTO users (full_name, email, password_hash)
                VALUES (%s, %s, %s)
            """, (full_name, email, hashed_pw))
            conn.commit()
            cur.close()
        finally:
            put_conn(conn)

        flash("Đăng ký thành công. Vui lòng đăng nhập!", "success")
        return redirect(url_for('login'))

    return render_template('sign_up.html')


@app.route('/about-us')
def about_us():
    return render_template('about-us.html', logged_in='user' in session, username=session.get('full_name'), avatar_url=session.get('avatar'))

@app.route('/contact-us')
def contact_us():
    return render_template('contact-us.html', logged_in='user' in session, username=session.get('full_name'), avatar_url=session.get('avatar'))

@app.route('/privacy-policy')
def privacy_policy():
    return render_template('privacy-policy.html', logged_in='user' in session, username=session.get('full_name'), avatar_url=session.get('avatar'))

@app.route('/terms-and-conditions')
def terms_and_conditions():
    return render_template('terms-and-conditions.html', logged_in='user' in session, username=session.get('full_name'), avatar_url=session.get('avatar'))

@app.route('/building-process')
def building_process():
    return render_template('building-process.html', logged_in='user' in session, username=session.get('full_name'), avatar_url=session.get('avatar'))

# === Biểu đồ ===
def create_pie_chart():
    investment_file = DATABASE_DIR / "investment_results.csv"
    if not investment_file.exists():
        return None

    try:
        df = pd.read_csv(investment_file, encoding="utf-8-sig")
        df['Trọng số (%)'] = df['Trọng số (%)'].str.replace('%', '').astype(float)
    except Exception:
        return None

    if df.empty or df['Trọng số (%)'].isnull().all():
        return None

    labels = df['Danh mục đầu tư'].tolist()
    weights = df['Trọng số (%)'].tolist()
    n = len(labels)
    colors = plt.cm.Paired(range(n))
    fig, ax = plt.subplots(figsize=(max(6, 4 + n * 0.3), max(6, 4 + n * 0.3)))
    wedges, *_ = ax.pie(weights, labels=None, autopct='%1.1f%%', startangle=90, colors=colors)
    ax.axis('equal')
    ax.legend(wedges, labels, title="Danh mục đầu tư", loc="center left", bbox_to_anchor=(1, 0.5), labelspacing=0.8)
    fig.tight_layout()

    img = io.BytesIO()
    fig.savefig(img, format='png', dpi=150)
    img.seek(0)
    img_base64 = base64.b64encode(img.read()).decode('utf-8')
    plt.close(fig)
    return img_base64

def create_risk_return_chart(criteria_file, names_file, xi_investments, assume_one_based=None):
    try:
        # Đọc dữ liệu
        criteria_df = pd.read_csv(criteria_file, encoding="utf-8-sig")
        names_df = pd.read_csv(names_file, encoding="utf-8-sig")

        # Xoá cột Unnamed nếu có
        criteria_df = criteria_df.loc[:, ~criteria_df.columns.str.contains(r'^Unnamed')]
        names_df    = names_df.loc[:, ~names_df.columns.str.contains(r'^Unnamed')]
        criteria_df.reset_index(drop=True, inplace=True)
        names_df.reset_index(drop=True, inplace=True)

        # Chọn cột tên danh mục
        name_col = "Danh mục" if "Danh mục" in names_df.columns else \
                   ("Danh mục đầu tư" if "Danh mục đầu tư" in names_df.columns else None)
        if name_col is None:
            raise KeyError("Không tìm thấy cột tên danh mục ('Danh mục' hoặc 'Danh mục đầu tư').")

        # xi_investments luôn là list int
        xi = [int(x) for x in xi_investments]

        # Lấy tên tương ứng
        selected_names = names_df.iloc[xi][name_col].tolist()

        if not selected_names:
            return None

        # Merge với criteria_df
        merged = pd.concat([names_df, criteria_df], axis=1)
        merged = merged.iloc[xi]   # lấy theo chỉ số xi


        if merged.empty:
            return None

        # Lấy dữ liệu cần thiết
        selected_criteria = merged[["Expected Return", "Risk"]].astype(float)
        selected_names    = merged[name_col].astype(str)

        # Sắp xếp theo Risk
        order = selected_criteria["Risk"].values.argsort()
        risks   = selected_criteria["Risk"].values[order]
        returns = selected_criteria["Expected Return"].values[order]
        names_sorted = selected_names.values[order]

        # Vẽ
        n = len(names_sorted)
        fig, ax = plt.subplots(figsize=(max(6, 4 + n * 0.3), 6))

        ax.plot(risks, returns, linewidth=2, linestyle="-", alpha=0.9)

        colors = plt.cm.Paired(range(n))
        handles = []
        for i in range(n):
            h = ax.scatter(risks[i], returns[i], s=120, alpha=0.9, color=colors[i])
            handles.append(h)

        ax.set_xlabel("Rủi ro")
        ax.set_ylabel("Lợi nhuận kỳ vọng")
        ax.grid(True, linestyle="--", alpha=0.6)

        legend = ax.legend(
            handles, names_sorted, title="Danh mục đầu tư",
            loc="upper left", fontsize=9, title_fontsize=10,
            frameon=True
        )
        legend.get_frame().set_facecolor("white")
        legend.get_frame().set_alpha(0.7)

        fig.tight_layout()

        # Xuất base64
        buf = io.BytesIO()
        fig.savefig(buf, format="png", dpi=150, bbox_inches="tight")
        buf.seek(0)
        img_base64 = base64.b64encode(buf.read()).decode("utf-8")
        plt.close(fig)
        return img_base64

    except Exception as e:
        print(f"Lỗi khi tạo biểu đồ: {e}")
        return None


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)

