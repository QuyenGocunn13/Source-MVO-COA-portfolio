import os
import csv
import numpy as np
import pandas as pd

# Tính toán trọng số tiêu chí
class CriteriaManager:
    def __init__(self, data_file, criteria_file, file_path):
        self.data_file = os.path.join(file_path, data_file)
        self.criteria_file = os.path.join(file_path, criteria_file)
        self.criteria_data = []
        self.normalized_scores = []
        self.weights = []
        self.weights_percent = []
        self.criteria_values = []
        self.investment_names = []
        self.criteria_estimated = []
        self.risk_estimated = []

    def read_csv_to_array(self):
        try:
            with open(self.data_file, mode='r') as file:
                reader = csv.reader(file)
                next(reader)  # Bỏ qua dòng tiêu đề
                return [float(row[0]) for row in reader]
        except FileNotFoundError:
            print(f"Không tìm thấy file: {self.data_file}. Vui lòng kiểm tra lại đường dẫn.")
            return []

    def normalize_to_nine_scale(self, data):
        max_val, min_val = max(data), min(data)
        if max_val == min_val:
            return [5] * len(data)
        return [round(1 + 8 * (val - min_val) / (max_val - min_val)) for val in data]

    def create_comparison_matrix(self, scores):
        n = len(scores)
        matrix = np.ones((n, n))
        for i in range(n):
            for j in range(n):
                if i != j:
                    matrix[i][j] = scores[i] / scores[j]
        return matrix

    def compute_weights(self):
        self.criteria_data = self.read_csv_to_array()
        if not self.criteria_data:
            return []

        self.normalized_scores = self.normalize_to_nine_scale(self.criteria_data)
        matrix = self.create_comparison_matrix(self.normalized_scores)

        col_sum = np.sum(matrix, axis=0)
        normalized_matrix = matrix / col_sum

        self.weights = np.mean(normalized_matrix, axis=1)
        self.weights_percent = self.weights / np.sum(self.weights) * 100

        return self.weights

    def load_criteria_values(self):
        file_path = os.path.join(os.path.dirname(self.data_file), "criteria_values.csv")
        try:
            df = pd.read_csv(file_path, encoding="utf-8")
            self.criteria_values = df.to_numpy()
        except FileNotFoundError:
            print(f"Không tìm thấy file: {file_path}. Vui lòng kiểm tra lại.")
            
    def load_investment_data(self):
        file_path = os.path.join(os.path.dirname(self.data_file), "criteria_and_risk_investment.csv")
        try:
            df = pd.read_csv(file_path, encoding="utf-8")
            self.investment_names = df["Danh mục"]
            self.criteria_estimated = df["Criteria Estimated"]
            self.risk_estimated = df["Risk Estimated"]
        except FileNotFoundError:
            print(f"Không tìm thấy file: {file_path}. Vui lòng kiểm tra lại.")

