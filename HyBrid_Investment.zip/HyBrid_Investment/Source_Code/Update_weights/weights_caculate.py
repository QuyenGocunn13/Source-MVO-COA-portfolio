import json
import pandas as pd
from pathlib import Path

from Update_weights.compute_scores import compute_asset_scores, compute_category_scores
from Update_weights.data_bank_caculate import calculate_bank_scores
from Update_weights.bond_caculate import calculate_bond_scores
from Update_weights.nav_caculate import get_fund_scores
from Update_weights.bds_caculate import get_real_estate_scores
from Update_weights.cw_caculate import get_cw_scores

BASE_DIR = Path(__file__).resolve().parent.parent
DATABASE_DIR = BASE_DIR / "database"

# ===== Đọc dữ liệu JSON =====
with open(DATABASE_DIR / "market_data.json", "r", encoding="utf-8") as f:
    data = json.load(f)

# ===== Gom dữ liệu =====
asset_list = []

for category, assets in data.items():
    if isinstance(assets, list):
        for item in assets:
            if all(item.get(k) is not None for k in ['current', 'high', 'low', 'open']):
                asset_list.append({
                    'symbol': item['symbol'],
                    'current': item['current'],
                    'high': item['high'],
                    'low': item['low'],
                    'open': item['open'],
                    'volume': item.get('volume'),
                    'category': category
                })
    elif isinstance(assets, dict):
        for sub_cat, items in assets.items():
            for item in items:
                current = item.get('current')
                high = item.get('high') or current
                low = item.get('low') or current
                open_price = item.get('open') or current

                if current is not None:
                    asset_list.append({
                        'symbol': item['symbol'],
                        'current': current,
                        'high': high,
                        'low': low,
                        'open': open_price,
                        'volume': item.get('volume'),
                        'category': sub_cat
                    })

df_assets = pd.DataFrame(asset_list)

# ===== Tính điểm =====
scores = compute_asset_scores(df_assets).reset_index().rename(columns={'index':'symbol'})

# ===== Index tùy ý =====
custom_index_map = {
    'Gửi ngân hàng': 0,
    'Cổ phiếu': 1,
    'Trái phiếu doanh nghiệp': 2,
    'Quỹ cổ phiếu': 3,
    'Quỹ trái phiếu': 4,
    'Quỹ hỗn hợp cân bằng': 5,
    'Crypto (btc / eth)': 6,
    'Alt coin': 7,
    'Hợp đồng tương lai': 8,
    'Chứng quyền đảm bảo (CW)': 9,
    'Đầu tư vàng': 10,
    'Đầu tư bạc': 11,
    'Bất động sản': 12
}

# ===== Tính điểm trung bình theo danh mục =====
category_scores_df = compute_category_scores(scores)
category_scores_df.index = category_scores_df.index.map(lambda x: custom_index_map.get(x, 99))

columns = [
    'Expected Return', 'Risk', 'Liquidity',
    'Investment Horizon', 'Cost', 'Stability of Cash Flow', 'Diversification'
]

# ===== Tính điểm các danh mục đặc biệt =====
bank_scores = pd.DataFrame([calculate_bank_scores(DATABASE_DIR / "lai_suat_lien_ngan_hang.csv")],
                           columns=columns, index=[custom_index_map['Gửi ngân hàng']])
bond_scores = pd.DataFrame([calculate_bond_scores(DATABASE_DIR / "bond_crawl.csv")],
                           columns=columns, index=[custom_index_map['Trái phiếu doanh nghiệp']])
stock_fund_scores = get_fund_scores(DATABASE_DIR / "nav_equity_last_7_days.csv",
                                    custom_index_map['Quỹ cổ phiếu'], columns, fund_type="equity")
bond_fund_scores = get_fund_scores(DATABASE_DIR / "nav_bond_last_7_days.csv",
                                   custom_index_map['Quỹ trái phiếu'], columns, fund_type="bond")
balanced_fund_scores = get_fund_scores(DATABASE_DIR / "nav_balanced_last_7_days.csv",
                                       custom_index_map['Quỹ hỗn hợp cân bằng'], columns, fund_type="balanced")
bds_scores = get_real_estate_scores(DATABASE_DIR / "real_estate_stocks.csv",
                                    custom_index_map['Bất động sản'], columns)
cw_scores = get_cw_scores(DATABASE_DIR / "CW_data_top10.csv",
                           custom_index_map['Chứng quyền đảm bảo (CW)'], columns)

# ===== Gom tất cả điểm =====
category_scores_df = pd.concat([
    category_scores_df,
    bank_scores,
    bond_scores,
    stock_fund_scores,
    bond_fund_scores,
    balanced_fund_scores,
    bds_scores,
    cw_scores
])

category_scores_df = category_scores_df.fillna(0).astype(int)
category_scores_df = category_scores_df.sort_index(ascending=True)

# ===== Lưu file CSV tạm với điểm số =====
category_scores_df.to_csv(DATABASE_DIR / "criteria_values.csv", index=False)
print("✅ Đã lưu xong criteria_values.csv với index đã sắp xếp")

# ===== Cập nhật Criteria Estimated và Risk Estimated từ điểm số =====
df_values = category_scores_df  # Dùng luôn DataFrame vừa tính
df_invest = pd.read_csv(DATABASE_DIR / "criteria_and_risk_investment.csv")

def score_to_level(score):
    if score < 5:
        return "Thấp"
    elif 5 <= score < 8:
        return "Trung bình"
    else:
        return "Cao"

df_invest['Criteria Estimated'] = df_values['Expected Return'].apply(score_to_level)
df_invest['Risk Estimated'] = df_values['Risk'].apply(score_to_level)

# Lưu trực tiếp CSV đã cập nhật
df_invest.to_csv(DATABASE_DIR / "criteria_and_risk_investment.csv", index=False)
print("✅ Đã cập nhật xong Criteria Estimated và Risk Estimated trong file CSV gốc!")
