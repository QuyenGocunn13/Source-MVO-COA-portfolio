import random
import pandas as pd

def clean_real_estate_data(csv_path: str) -> pd.DataFrame:
    """
    Đọc và làm sạch dữ liệu bất động sản:
    - Chuyển 'price' về float
    - Chuẩn hóa 'change' (loại bỏ dấu phẩy, ép float)
    - Chuẩn hóa 'percent' (loại bỏ %, ép float)
    """
    df = pd.read_csv(csv_path, encoding="utf-8")

    # Giá
    df["price"] = (
        df["price"].astype(str)
        .str.replace(",", "", regex=False)
        .str.strip()
        .astype(float)
    )

    # Thay đổi tuyệt đối
    df["change"] = (
        df["change"].astype(str)
        .str.replace(",", "", regex=False)
        .str.strip()
        .astype(float)
    )

    # Thay đổi %
    df["percent"] = (
        df["percent"].astype(str)
        .str.replace("%", "", regex=False)
        .str.replace(",", ".", regex=False)  # phòng dữ liệu thập phân kiểu EU
        .str.strip()
        .astype(float)
    )

    # Loại bỏ dòng lỗi (NaN)
    df = df.dropna(subset=["price", "change", "percent"])

    return df


def get_real_estate_scores(csv_path: str, index: int, columns: list) -> pd.DataFrame:
    """
    Tính điểm tiêu chí bất động sản dựa trên dữ liệu đã clean.
    """
    df = clean_real_estate_data(csv_path)

    # Hàm scale về 1–10 (không có 0)
    def scale(x, min_val, max_val):
        if max_val == min_val:
            return 5
        val = 1 + 9 * (x - min_val) / (max_val - min_val)
        return round(max(1, min(val, 10)))

    # 1. Expected Return: trung bình % thay đổi
    avg_return = df["percent"].mean()
    exp_return_score = scale(avg_return, df["percent"].min(), df["percent"].max())

    # 2. Risk: độ lệch chuẩn % thay đổi
    risk_val = df["percent"].std()
    risk_score = scale(risk_val, 0, df["percent"].std() * 2)

    # 3. Liquidity: biến động nhỏ → điểm cao
    avg_abs_change = df["change"].abs().mean()
    liquidity_score = scale(df["change"].max() - avg_abs_change, 0, df["change"].max())

    # 4. Cost: giá thấp → điểm cao
    cost_score = scale(
        df["price"].max() - df["price"].mean(), df["price"].min(), df["price"].max()
    )

    # 5. Stability: biến động nhỏ → điểm cao
    stability_score = scale(df["change"].max() - avg_abs_change, 0, df["change"].max())

    # 6. Diversification: số lượng mã → giả định
    diversification_score = random.randint(5, 8)

    # 7. Investment Horizon: dựa trên lợi nhuận trung bình
    investment_horizon = scale(avg_return, df["percent"].min(), df["percent"].max())

    result = pd.DataFrame(
        [
            {
                "Index": index,
                "Expected Return": exp_return_score,
                "Risk": risk_score,
                "Liquidity": liquidity_score,
                "Investment Horizon": investment_horizon,
                "Cost": cost_score,
                "Stability of Cash Flow": stability_score,
                "Diversification": diversification_score,
            }
        ],
        columns=columns,
        index=[index],
    )

    return result
