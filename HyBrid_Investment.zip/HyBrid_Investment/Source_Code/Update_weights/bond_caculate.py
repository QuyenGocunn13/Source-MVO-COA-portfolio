import pandas as pd

def calculate_bond_scores(csv_path):
    """
    Đọc file CSV trái phiếu ngắn hạn, tính điểm tiêu chí cho 7 ngày gần nhất
    và trả về danh sách trung bình điểm.
    """
    bond_data = pd.read_csv(csv_path, encoding="utf-8", dayfirst=True)
    
    # --- Chuyển dữ liệu sang số ---
    numeric_cols = ["Lần cuối", "Mở", "Cao", "Thấp"]
    for col in numeric_cols:
        bond_data[col] = bond_data[col].astype(str).str.replace(',', '').astype(float)
    
    bond_data["% Thay đổi"] = bond_data["% Thay đổi"].astype(str).str.replace('%','').astype(float)
    
    # --- Chỉ lấy 7 ngày gần nhất ---
    bond_data["Ngày"] = pd.to_datetime(bond_data["Ngày"], dayfirst=True)
    bond_data = bond_data.sort_values("Ngày", ascending=False).head(7)

    # ===== Thang điểm =====
    min_profit_score = 3
    max_profit_score = 9
    min_risk_score = 1
    max_risk_score = 10

    # --- Expected Return ---
    max_price = bond_data["Lần cuối"].max()
    min_price = bond_data["Lần cuối"].min()
    
    def scale_profit(x):
        return ((x - min_price) / (max_price - min_price)) * (max_profit_score - min_profit_score) + min_profit_score
    
    bond_data["Expected Return"] = (
        bond_data["Lần cuối"].apply(scale_profit)
        .round().clip(min_profit_score, max_profit_score).astype(int)
    )

    # --- Risk ---
    bond_data["Rủi_ro_tương_đối"] = bond_data["Cao"] - bond_data["Thấp"]
    max_risk_observed = bond_data["Rủi_ro_tương_đối"].max()
    
    def scale_risk(x):
        return (x / max_risk_observed) * (max_risk_score - min_risk_score) + min_risk_score
    
    bond_data["Risk"] = (
        bond_data["Rủi_ro_tương_đối"].apply(scale_risk)
        .round().clip(min_risk_score, max_risk_score).astype(int)
    )

    # --- Liquidity ---
    bond_data["Liquidity"] = 9

    # --- Investment Horizon ---
    bond_data["Ngày_hạn_số"] = 730
    max_term = bond_data["Ngày_hạn_số"].max()
    bond_data["Investment Horizon"] = (
        ((max_term - bond_data["Ngày_hạn_số"]) / max_term * 10)
        .round().clip(1, 10).astype(int)
    )

    # --- Cost ---
    bond_data["Cost"] = 2

    # --- Stability of Cash Flow ---
    bond_data["Stability of Cash Flow"] = (max_risk_score + min_risk_score) - bond_data["Risk"]

    # --- Diversification ---
    bond_data["Diversification"] = 2

    # --- Trung bình 7 ngày ---
    cols = ["Expected Return", "Risk", "Liquidity", "Investment Horizon",
            "Cost", "Stability of Cash Flow", "Diversification"]
    
    averages = bond_data[cols].mean().round().astype(int).tolist()
    return averages
