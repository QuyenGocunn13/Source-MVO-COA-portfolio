import pandas as pd
import random

def get_cw_scores(csv_path: str, index: int, columns: list) -> pd.DataFrame:
    df = pd.read_csv(csv_path, encoding="utf-8")

    # Chuẩn hóa dữ liệu
    df['Giá đóng cửa'] = df['Giá đóng cửa'].astype(str).str.replace(',', '').astype(float)
    df['Thay đổi %'] = df['Thay đổi'].str.extract(r'([-+]?[0-9]*\.?[0-9]+)%').astype(float)
    df['Ngày GDCC'] = pd.to_datetime(df['Ngày GDCC'], dayfirst=True, errors="coerce")
    
    today = pd.Timestamp.today()
    df['days_to_maturity'] = (df['Ngày GDCC'] - today).dt.days.clip(lower=0)

    # Hàm scale về 1–10
    def scale(x, min_val, max_val, reverse=False):
        if pd.isna(x) or max_val == min_val:
            return 5
        score = (x - min_val) / (max_val - min_val) * 9 + 1
        if reverse:  # trường hợp càng thấp càng tốt (cost, risk, volatility)
            score = 11 - score
        return int(round(min(max(score, 1), 10)))


    # 1. Expected Return: trung bình % thay đổi
    avg_return = df['Thay đổi %'].mean()
    exp_return_score = scale(avg_return, df["Thay đổi %"].min(), df["Thay đổi %"].max())

    # 2. Risk: độ lệch chuẩn % thay đổi
    risk_val = df['Thay đổi %'].std()
    risk_score = scale(risk_val, 0, df["Thay đổi %"].std() * 2, reverse=True)

    # 3. Liquidity: giả định thanh khoản cao do CW giao dịch ngắn hạn
    liquidity_score = 8

    # 4. Cost: dùng giá trung bình, giá càng thấp điểm càng cao
    avg_price = df['Giá đóng cửa'].mean()
    cost_score = scale(avg_price, df['Giá đóng cửa'].min(), df['Giá đóng cửa'].max(), reverse=True)

    # 5. Stability: dùng độ lệch chuẩn của % thay đổi, std càng thấp điểm càng cao
    stability_val = df['Thay đổi %'].std()
    max_vol = 15 
    stability_score = scale(stability_val, 0, max_vol, reverse=True)


    # 6. Diversification: số mã CW
    diversification_score = random.randint(7, 9) 

    # 7. Investment Horizon: số ngày trung bình còn lại
    avg_days = df['days_to_maturity'].mean()
    investment_horizon = scale(avg_days, df['days_to_maturity'].min(), df['days_to_maturity'].max())

    # Kết quả cuối
    result = pd.DataFrame([{
        "Index": index,
        "Expected Return": exp_return_score,
        "Risk": risk_score,
        "Liquidity": liquidity_score,
        "Investment Horizon": investment_horizon,
        "Cost": cost_score,
        "Stability of Cash Flow": stability_score,
        "Diversification": diversification_score
    }], columns=columns, index=[index])

    return result
