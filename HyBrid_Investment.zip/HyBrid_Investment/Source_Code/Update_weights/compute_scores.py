import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
import random

# ===== Tính điểm cho từng tài sản =====
def compute_asset_scores(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df['return'] = (df['current'] - df['open']) / df['open']
    df['range'] = (df['high'] - df['low']) / df['open']
    df['inv_range'] = np.log1p(1 / (df['range'].clip(lower=1e-4)))

    def is_special(row):
        symbol = str(row['symbol']).lower()
        category = str(row.get('category', '')).lower()
        return (
            category in ['futures', 'gold & silver'] or
            'gold' in symbol.lower() or
            'silver' in symbol.lower()
        )

    df['special_stability'] = df.apply(is_special, axis=1)
    df['stability'] = np.where(
        df['special_stability'],
        np.nan,
        1 / df['range'].replace(0, 1e-8)
    )

    cols = ['return', 'range', 'stability']
    df_scores = pd.DataFrame(index=df['symbol'])
    df_to_scale = df.set_index('symbol')[cols].copy()
    df_to_scale['stability'] = df_to_scale['stability'].where(~df['special_stability'])

    scaler = MinMaxScaler(feature_range=(0.05, 0.95))
    scaled_df = pd.DataFrame(
        scaler.fit_transform(df_to_scale.fillna(0)),
        index=df_to_scale.index,
        columns=[f"{col}_s" for col in cols]
    )

    for col in cols:
        scores = (scaled_df[f"{col}_s"] * 9 + 1).round().astype(int)
        if col == 'return':
            df_scores['exp_return_score'] = scores
        elif col == 'range':
            df_scores['risk_score'] = scores
        else:
            df_scores['stability_score'] = scores

    np.random.seed(42)
    special_symbols = df[df['special_stability']]['symbol']
    df_scores.loc[special_symbols, 'stability_score'] = np.random.randint(1, 3, size=len(special_symbols))

    # Tính liquidity_score
    df['volume'] = df['volume'].fillna(np.nan)
    df['volume_usd'] = df['volume'] * df['current']
    df['volume_usd'] = df['volume_usd'].fillna(0)

    def assign_liquidity_score(row):
        if pd.isna(row['volume_usd']):
            return random.randint(3, 5)
        elif row['volume_usd'] >= 100_000_000:
            return 9
        elif row['volume_usd'] >= 50_000_000:
            return 7
        elif row['volume_usd'] >= 10_000_000:
            return 5
        elif row['volume_usd'] >= 1_000_000:
            return 3
        else:
            return random.randint(5, 7)

    df['liquidity_score'] = df.apply(assign_liquidity_score, axis=1)
    df_scores['liquidity_score'] = df.set_index('symbol')['liquidity_score']

    df_scores['cost_score'] = 5
    df_scores['diversification_score'] = 5

    def classify_horizon(row):
        score = (
            (10 - row.get('risk_score', 5)) * 0.4 +
            (10 - row.get('exp_return_score', 5)) * 0.2 +
            row.get('stability_score', 5) * 0.3 +
            (10 - row.get('liquidity_score', 5)) * 0.1
        )
        if score <= 4:
            return 1
        elif score <= 7:
            return 2
        else:
            return 3

    df_scores['investment_horizon'] = df_scores.apply(classify_horizon, axis=1)

    df_scores = df_scores.rename(columns={
        "exp_return_score": "Expected Return",
        "risk_score": "Risk",
        "liquidity_score": "Liquidity",
        "investment_horizon": "Investment Horizon",
        "cost_score": "Cost",
        "stability_score": "Stability of Cash Flow",
        "diversification_score": "Diversification"
    })
    return df_scores[[
        "Expected Return", "Risk", "Liquidity", "Investment Horizon",
        "Cost", "Stability of Cash Flow", "Diversification"
    ]]


# ===== Phân loại danh mục và tính điểm trung bình =====
def get_asset_category(symbol, sub_cat=None):
    symbol = symbol.upper()
    if symbol in ['BINANCE:BTCUSDT', 'BINANCE:ETHUSDT', 'BTCUSDT', 'ETHUSDT']:
        return 'Crypto (btc / eth)'  # <--- sửa lại để khớp map
    elif symbol in ['BINANCE:SOLUSDT', 'BINANCE:XRPUSDT', 'BINANCE:ADAUSDT',
                    'SOLUSDT', 'XRPUSDT', 'ADAUSDT']:
        return 'Alt coin'
    elif 'BINANCE:' in symbol:
        return 'Alt coin'
    elif symbol in ['XAUUSD', 'GOLD']:
        return 'Đầu tư vàng'
    elif symbol in ['XAGUSD', 'SILVER']:
        return 'Đầu tư bạc'
    elif symbol.endswith('.VN'):
        return 'Cổ phiếu'
    else:
        return 'Hợp đồng tương lai'


def compute_category_scores(df: pd.DataFrame):
    df = df.copy()
    df['category'] = df.apply(lambda row: get_asset_category(row['symbol'], row.get('category')), axis=1)
    score_cols = [
        "Expected Return", "Risk", "Liquidity", "Investment Horizon",
            "Cost", "Stability of Cash Flow", "Diversification"
    ]
    return df.groupby('category')[score_cols].mean().round(0).astype(int)
