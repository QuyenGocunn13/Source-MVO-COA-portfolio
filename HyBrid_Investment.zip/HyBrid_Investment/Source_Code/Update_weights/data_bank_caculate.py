import pandas as pd
from pathlib import Path

def calculate_bank_scores(csv_path):
    """
    Đọc file CSV lãi suất liên ngân hàng rồi tính điểm tiêu chí,
    trả về list điểm theo 7 tiêu chí chuẩn.
    """
    lien_ngan_hang = pd.read_csv(csv_path, encoding="utf-8")

    # --- Làm sạch dữ liệu ---
    # Cột lãi suất: bỏ ký tự (*), đổi dấu phẩy thành chấm
    lien_ngan_hang["Lãi suất BQ liên Ngân hàng (% năm)"] = (
        lien_ngan_hang["Lãi suất BQ liên Ngân hàng (% năm)"]
        .astype(str)
        .str.replace(r"\(\*\)", "", regex=True)
        .str.replace(",", ".", regex=False)
        .str.strip()
        .astype(float)
    )

    # Cột doanh số: bỏ ký tự (*), đổi dấu phẩy thành chấm
    lien_ngan_hang["Doanh số (Tỷ đồng)"] = (
        lien_ngan_hang["Doanh số (Tỷ đồng)"]
        .astype(str)
        .str.replace(r"\(\*\)", "", regex=True)
        .str.replace(",", ".", regex=False)
        .str.strip()
        .astype(float)
    )

    min_profit_score = 3
    max_profit_score = 8
    min_risk_score = 1
    max_risk_score = 10

    # ----- Lợi nhuận -----
    max_rate = lien_ngan_hang["Lãi suất BQ liên Ngân hàng (% năm)"].max()
    min_rate = lien_ngan_hang["Lãi suất BQ liên Ngân hàng (% năm)"].min()

    def scale_profit(x):
        return ((x - min_rate) / (max_rate - min_rate)) * (max_profit_score - min_profit_score) + min_profit_score

    lien_ngan_hang["Expected Return"] = (
        lien_ngan_hang["Lãi suất BQ liên Ngân hàng (% năm)"]
        .apply(scale_profit).round().clip(min_profit_score, max_profit_score).astype(int)
    )

    # ----- Rủi ro -----
    mean_rate = lien_ngan_hang["Lãi suất BQ liên Ngân hàng (% năm)"].mean()
    lien_ngan_hang["Rủi_ro_tương_đối"] = abs(lien_ngan_hang["Lãi suất BQ liên Ngân hàng (% năm)"] - mean_rate)
    max_risk_observed = lien_ngan_hang["Rủi_ro_tương_đối"].max()

    def scale_risk(x):
        return (x / max_risk_observed) * (max_risk_score - min_risk_score) + min_risk_score

    lien_ngan_hang["Risk"] = (
        lien_ngan_hang["Rủi_ro_tương_đối"].apply(scale_risk)
        .round().clip(min_risk_score, max_risk_score).astype(int)
    )

    # ----- Thanh khoản -----
    lien_ngan_hang["Liquidity"] = 10

    # ----- Thời gian đầu tư -----
    def convert_term(term):
        term = str(term).strip()
        if "Qua đêm" in term: return 1
        if "1 Tuần" in term: return 7
        if "2 Tuần" in term: return 14
        if "1 Tháng" in term: return 30
        if "3 Tháng" in term: return 90
        if "6 Tháng" in term: return 180
        if "9 Tháng" in term: return 270
        return 999

    lien_ngan_hang["Ngày_hạn_số"] = lien_ngan_hang["Thời hạn"].apply(convert_term)
    max_term = lien_ngan_hang["Ngày_hạn_số"].max()
    lien_ngan_hang["Investment Horizon"] = (
        ((max_term - lien_ngan_hang["Ngày_hạn_số"]) / max_term * 10)
        .round().clip(1, 10).astype(int)
    )

    # ----- Các chỉ số cố định -----
    lien_ngan_hang["Cost"] = 1
    lien_ngan_hang["Stability of Cash Flow"] = (max_risk_score + min_risk_score) - lien_ngan_hang["Risk"]
    lien_ngan_hang["Diversification"] = 1

    cols = ["Expected Return", "Risk", "Liquidity", "Investment Horizon",
            "Cost", "Stability of Cash Flow", "Diversification"]

    averages = lien_ngan_hang[cols].mean().round().astype(int).tolist()
    return averages
