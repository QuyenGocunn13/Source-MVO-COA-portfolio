import pandas as pd

def clean_fund_data(csv_path: str) -> pd.DataFrame:
    """
    Đọc và làm sạch dữ liệu quỹ:
    - date: parse datetime
    - nav_per_unit: chuyển số, loại bỏ NaN
    - fund_code: chuẩn hóa dạng string
    """
    df = pd.read_csv(csv_path, encoding="utf-8")

    # Chuẩn hóa fund_code
    if "fund_code" not in df.columns:
        raise ValueError("CSV thiếu cột 'fund_code'")
    df["fund_code"] = df["fund_code"].astype(str).str.strip()

    # Parse date
    if "date" not in df.columns:
        raise ValueError("CSV thiếu cột 'date'")
    df["date"] = pd.to_datetime(df["date"], errors="coerce")

    # NAV
    if "nav_per_unit" not in df.columns:
        raise ValueError("CSV thiếu cột 'nav_per_unit'")
    df["nav_per_unit"] = (
        df["nav_per_unit"].astype(str)
        .str.replace(",", "", regex=False)
        .str.strip()
        .astype(float)
    )

    # Bỏ NaN quan trọng
    df = df.dropna(subset=["date", "nav_per_unit", "fund_code"])

    return df


def get_fund_scores(csv_path: str, index: int, columns: list, fund_type: str) -> pd.DataFrame:
    """
    Tính điểm các tiêu chí cho nhóm quỹ (equity / bond / balanced).
    """
    df = clean_fund_data(csv_path)

    # Sắp xếp và lấy 30 ngày gần nhất cho từng quỹ
    df = df.sort_values(["fund_code", "date"], ascending=[True, False])
    df = df.groupby("fund_code").head(30)

    # % thay đổi NAV (daily return)
    df["return"] = df.groupby("fund_code")["nav_per_unit"].pct_change()

    # Trung bình và độ biến động
    avg_returns = df.groupby("fund_code")["return"].mean()
    vol = df.groupby("fund_code")["return"].std()

    # Scale lợi nhuận (1–9)
    min_profit, max_profit = avg_returns.min(), avg_returns.max()
    def scale_profit(x):
        if pd.isna(x) or max_profit == min_profit:
            return 5
        return ((x - min_profit) / (max_profit - min_profit)) * 8 + 1
    profit_scores = avg_returns.apply(scale_profit).round().clip(1, 9).fillna(5)

    # Scale rủi ro (1–10)
    min_risk, max_risk = vol.min(), vol.max()
    def scale_risk(x):
        if pd.isna(x) or max_risk == min_risk:
            return 5
        return ((x - min_risk) / (max_risk - min_risk)) * 9 + 1
    risk_scores = vol.apply(scale_risk).round().clip(1, 10).fillna(5)

    # Gán tiêu chí theo loại quỹ
    if fund_type == "equity":        # Quỹ cổ phiếu
        time, fee, stability, diversity = 7, 3, 4, 3
    elif fund_type == "bond":        # Quỹ trái phiếu
        time, fee, stability, diversity = 4, 1, 9, 5
    elif fund_type == "balanced":    # Quỹ cân bằng
        time, fee, stability, diversity = 6, 2, 6, 7
    else:
        raise ValueError("fund_type phải là 'equity', 'bond', 'balanced'")

    liquidity = 9  # chung cho tất cả

    # Tạo DataFrame kết quả
    result = pd.DataFrame([{
        "Index": index,
        "Expected Return": int(profit_scores.mean()),  # trung bình các quỹ
        "Risk": int(risk_scores.mean()),
        "Liquidity": liquidity,
        "Investment Horizon": time,
        "Cost": fee,
        "Stability of Cash Flow": stability,
        "Diversification": diversity
    }], columns=columns, index=[index])

    return result
