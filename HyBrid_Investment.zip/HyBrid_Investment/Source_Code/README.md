# Investment Project - Flask + PostgreSQL (Docker)

[![Python](https://img.shields.io/badge/Python-3.11-blue)](https://www.python.org/)
[![Docker](https://img.shields.io/badge/Docker-Yes-blue)](https://www.docker.com/)
[![License](https://img.shields.io/badge/License-Internal-lightgrey)](#)

## 1️⃣ Giới thiệu

Project web **Flask** kết hợp **PostgreSQL** để quản lý và gợi ý danh mục đầu tư.
Sử dụng **Docker & Docker Compose** để dễ dàng chạy trên mọi máy, đặc biệt dành cho **team nội bộ**.

---

## 2️⃣ Yêu cầu

* Docker
* Docker Compose
* Git

Kiểm tra phiên bản:

```bash
docker --version
docker-compose --version
```

---

## 3️⃣ Clone project

```bash
git clone https://github.com/QuyenGocunn13/Source-MVO-COA-portfolio.git
cd Hybrid_Investment
```

---

## 4️⃣ Build & chạy server bằng Docker

```bash
docker-compose up --build
```

* Docker sẽ tạo 2 container:

  1. PostgreSQL (database)
  2. Flask server (web app)

* Chờ log xuất hiện:

```
✅ Kết nối PostgreSQL thành công!
* Running on http://0.0.0.0:5000
```

* Truy cập project trên trình duyệt:

```
http://localhost:5000
```

---

## 5️⃣ Quản lý server

* **Dừng server**:

```bash
docker-compose down
```

```bash
Terminal:CTRL+C
```

---

## 6️⃣7️ Lưu ý cho team nội bộ
* Lần đầu chạy, Docker tự tạo database và tables từ thư mục `init-db`.
