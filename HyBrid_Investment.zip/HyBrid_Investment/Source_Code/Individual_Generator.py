import numpy as np
import random

#Import class
from Algorithm_Parameters import AlgorithmParameters


# Khởi tạo cấu hình thuật toán
config = AlgorithmParameters()
parameters = config.get_parameters()
pop_size = parameters["pop_size"]
bounds = parameters["bounds"]
max_iter = parameters["max_iter"]
switch_iter = parameters["switch_iter"]
data = parameters["data"]

# Tạo một cá thể:
class IndividualGenerator:
    def __init__(self, criteria_manager, pop_size):
        self.criteria_manager = criteria_manager
        self.pop_size = pop_size

    # Xác định số biến n_bien dựa trên weights
    def determine_n_bien(self):
        sorted_indices = np.argsort(self.criteria_manager.weights)[-3:]
        return 10 if 6 in sorted_indices else 6

    # Hàm tạo 1 cá thể
    def create_individual(self, n_bien):
        n = n_bien // 2  # Số lượng cặp (xi, yi)
        individual = [0] * n_bien  # Cá thể chứa n_bien giá trị

        # Tạo các giá trị xi (có thể trùng nhau nếu cần)
        xi_values = random.sample(range(13), k=n)

        for i, xi in enumerate(xi_values):
            individual[2 * i] = xi

        # Tạo các giá trị yi với tổng là 100, đảm bảo giữ nguyên tổng sau khi làm tròn
        alpha = max(3, 12 - n_bien) 
        yi_values = np.random.dirichlet(np.ones(n) * alpha) * 100

        yi_values = np.round(yi_values, 2)  # Làm tròn đến 2 chữ số

        # Điều chỉnh tổng để đảm bảo nó vẫn là 100 sau khi làm tròn
        difference = 100 - np.sum(yi_values)
        yi_values[np.argmax(yi_values)] += difference  # Điều chỉnh phần tử lớn nhất

        for i, yi in enumerate(yi_values):
            individual[2 * i + 1] = yi

        return individual
    def generate_population(self):
        n_bien = self.determine_n_bien()
        return [self.create_individual(n_bien) for _ in range(pop_size)]
