from imageio import save
import requests
import asyncio
import aiohttp
import sqlite3
import json
import time
import yfinance as yf  
from apscheduler.schedulers.asyncio import AsyncIOScheduler
import logging
from datetime import datetime
import pytz
from dotenv import load_dotenv
import os
from pathlib import Path

# --- Cấu hình logging ---
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('market_data.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# --- API Keys ---
load_dotenv()

FINNHUB_API_KEY = os.getenv("FINNHUB_API_KEY")
METALPRICEAPI_KEY = os.getenv("METALPRICEAPI_KEY")
ALPHA_VANTAGE_API_KEY = os.getenv("ALPHA_VANTAGE_API_KEY")

# --- Danh sách theo dõi ---
crypto_symbols = {
    "Crypto (btc / eth)": ["BINANCE:BTCUSDT", "BINANCE:ETHUSDT"],
    "Alt coin": ["BINANCE:SOLUSDT", "BINANCE:XRPUSDT", "BINANCE:ADAUSDT"]
}
futures_symbols = ["ES=F", "NQ=F", "CL=F", "GC=F", "SI=F"]  # Mã yfinance
stock_symbols = ["VNM.VN", "VIC.VN", "HPG.VN", "FPT.VN", "MWG.VN"]  # 5 mã VN

# --- Database Setup ---
conn = sqlite3.connect("market_data.db")
c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS quotes
             (symbol TEXT, type TEXT, current REAL, high REAL, low REAL, open REAL, prev_close REAL, timestamp INTEGER)''')

# --- Hàm kiểm tra dữ liệu cache ---
def check_cache(symbol, type_data):
    try:
        c.execute("SELECT current, high, low, open, prev_close, timestamp FROM quotes WHERE symbol = ? AND type = ? ORDER BY timestamp DESC LIMIT 1", (symbol, type_data))
        result = c.fetchone()
        if result:
            current, high, low, open_price, prev_close, timestamp = result
            if time.time() - timestamp < 24 * 3600:
                logger.info(f"Using cached {type_data} data for {symbol}: {current}")
                return {
                    "symbol": symbol,
                    "current": current,
                    "high": high,
                    "low": low,
                    "open": open_price,
                    "prev_close": prev_close,
                    "timestamp": timestamp,
                    "type": type_data
                }
        return None
    except Exception as e:
        logger.error(f"Error checking {type_data} cache for {symbol}: {e}")
        return None

# --- Hàm lấy giá từ Finnhub (Crypto) ---
async def fetch_finnhub_quote(symbol, session):
    url = f"https://finnhub.io/api/v1/quote?symbol={symbol}&token={FINNHUB_API_KEY}"
    try:
        async with session.get(url, timeout=10) as response:
            response.raise_for_status()
            data = await response.json()
            
            # Nếu API không trả về giá hiện tại, fallback sang giá gần nhất trong DB
            if not data or data.get("c") in [0, None]:
                logger.warning(f"No current price for {symbol}, using cached last value")
                cached = check_cache(symbol, "crypto")
                if cached:
                    return cached
                return None
            
            return {
                "symbol": symbol,
                "current": data.get("c"),
                "high": data.get("h"),
                "low": data.get("l"),
                "open": data.get("o"),
                "prev_close": data.get("pc"),
                "timestamp": data.get("t"),
                "type": "crypto"
            }
    except Exception as e:
        logger.error(f"Error fetching {symbol} from Finnhub: {e}")
        cached = check_cache(symbol, "crypto")
        return cached


# --- Hàm kiểm tra giờ giao dịch futures ---
def is_futures_trading_hours():
    now = datetime.now(pytz.timezone("Asia/Ho_Chi_Minh"))
    hour = now.hour
    return 20 <= hour or hour <= 7  # 8:00 PM - 7:00 AM +07

# --- Hàm lấy giá futures và stocks từ yfinance ---
def fetch_yfinance_data(symbol, type_data):
    cached_data = check_cache(symbol, type_data)
    if cached_data:
        return cached_data
    try:
        ticker = yf.Ticker(symbol)
        data = ticker.history(period="5d", interval="1d", auto_adjust=True)  # lấy 5 ngày phòng trống
        if data.empty:
            logger.warning(f"No data for {symbol}, using cache if available")
            return cached_data
        last_row = data.iloc[-1]  # luôn lấy giá gần nhất có sẵn
        return {
            "symbol": symbol,
            "current": round(last_row["Close"], 2),
            "high": round(last_row["High"], 2),
            "low": round(last_row["Low"], 2),
            "open": round(last_row["Open"], 2),
            "prev_close": round(data["Close"].iloc[-2] if len(data) > 1 else 0, 2),
            "timestamp": int(last_row.name.timestamp()),
            "type": type_data
        }
    except Exception as e:
        logger.error(f"Error fetching {symbol} from yfinance: {e}")
        return cached_data


# --- Hàm lấy giá kim loại quý từ MetalpriceAPI ---
def fetch_metals():
    url = f"https://api.metalpriceapi.com/v1/latest?api_key={METALPRICEAPI_KEY}&base=XAU&currencies=USD,XAG"
    try:
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()
        rates = resp.json().get("rates", {})
        result = []
        if "USD" in rates:
            result.append({"symbol": "XAUUSD", "current": round(rates["USD"], 2)})
        if "XAG" in rates and "USD" in rates:
            xau_usd = rates["USD"]
            xau_to_xag = rates["XAG"]
            xag_usd = round(xau_usd / xau_to_xag, 2)
            result.append({"symbol": "XAGUSD", "current": xag_usd})
        return result
    except Exception as e:
        logger.error(f"Error fetching metals data: {e}")
        return []

# --- Hàm lấy tất cả dữ liệu (Async) ---
async def fetch_all_quotes(symbols, fetch_function):
    async with aiohttp.ClientSession() as session:
        tasks = [fetch_function(symbol, session) for symbol in symbols]
        return await asyncio.gather(*tasks)

# --- Lưu vào database ---
def save_to_db(data):
    try:
        for category, items in data.items():
            if category == "crypto":
                for group, quotes in items.items():
                    for q in quotes:
                        c.execute("INSERT INTO quotes VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                                  (q["symbol"], "crypto", q["current"], q["high"], q["low"], q["open"], q["prev_close"], q["timestamp"]))
            elif category == "metals":
                for q in items["Gold & Silver"]:
                    c.execute("INSERT INTO quotes VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                              (q["symbol"], "metals", q["current"], None, None, None, None, None))
            elif category in ["futures", "stocks"]:
                for q in items:
                    c.execute("INSERT INTO quotes VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                              (q["symbol"], category, q["current"], q.get("high"), q.get("low"), q.get("open"), q.get("prev_close"), q.get("timestamp")))
        conn.commit()
        logger.info("Saved data to database successfully")
    except Exception as e:
        logger.error(f"Error saving to database: {e}")

# --- Hàm chính để lấy và lưu dữ liệu ---
async def update_market_data(filename="market_data_cpy.json"):
    logger.info("Starting market data update...")
    result = {
        "crypto": {},
        "futures": [],
        "stocks": [],
        "metals": {}
    }

    # Crypto (Finnhub)
    logger.info("Fetching crypto data from Finnhub...")
    for group, symbols in crypto_symbols.items():
        result["crypto"][group] = [q for q in await fetch_all_quotes(symbols, fetch_finnhub_quote) if q]
        for q in result["crypto"][group]:
            logger.info(f"{q['symbol']}: {q['current']}")

    # Futures (yfinance)
    logger.info("Fetching futures data from yfinance...")
    result["futures"] = [fetch_yfinance_data(symbol, "futures") for symbol in futures_symbols]
    result["futures"] = [q for q in result["futures"] if q]
    for q in result["futures"]:
        logger.info(f"{q['symbol']}: {q['current']}")

    # Stocks (yfinance)
    logger.info("Fetching stocks data from yfinance...")
    result["stocks"] = [fetch_yfinance_data(symbol, "stocks") for symbol in stock_symbols]
    result["stocks"] = [q for q in result["stocks"] if q]
    for q in result["stocks"]:
        logger.info(f"{q['symbol']}: {q['current']}")

    # Metals (MetalpriceAPI)
    logger.info("Fetching metals data from MetalpriceAPI...")
    result["metals"]["Gold & Silver"] = fetch_metals()
    for item in result["metals"]["Gold & Silver"]:
        logger.info(f"{item['symbol']}: {item['current']}")

    BASE_DIR = Path(__file__).resolve().parent
    DATABASE_DIR = BASE_DIR / "database"
    DATABASE_DIR.mkdir(exist_ok=True)
    save_path = DATABASE_DIR / filename  

    # Lưu vào file và database
    try:
        with open(save_path, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2, ensure_ascii=False)
        logger.info(f"Saved data to {save_path} successfully")
    except Exception as e:
        logger.error(f"Error saving to JSON file: {e}")

    save_to_db(result)
    logger.info("Completed market data update")

# --- Hàm chạy scheduler ---
async def run_scheduler():
    # Khởi tạo scheduler
    scheduler = AsyncIOScheduler(timezone=pytz.timezone("Asia/Ho_Chi_Minh"))
    
    # Lập lịch chạy vào 9:00 AM và 5:00 PM mỗi ngày
    scheduler.add_job(update_market_data, 'cron', hour=9, minute=0)
    scheduler.add_job(update_market_data, 'cron', hour=17, minute=0)
    
    # Chạy thử lần đầu
    logger.info("Running initial market data update...")
    await update_market_data()
    
    # Bắt đầu scheduler
    logger.info("Starting scheduler...")
    scheduler.start()
    
    try:
        # Giữ script chạy nền
        await asyncio.Event().wait()
    except (KeyboardInterrupt, SystemExit):
        logger.info("Stopping scheduler...")
        scheduler.shutdown()
        conn.close()
        logger.info("Closed database and exited program")

# --- MAIN ---
if __name__ == "__main__":
    asyncio.run(run_scheduler())