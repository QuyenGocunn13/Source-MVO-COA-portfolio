# Tính fitness của một cá thể
class Caculate_Fitness_Individual_Generator:
    @staticmethod
    def calculate_fitness(fitness_investment, population):
        fitness_values = []  # Danh sách chứa fitness của từng cá thể

        for individual in population:
            individual_fitness = 0
            for j in range(0, len(individual), 2):  # Duyệt qua các giá trị xi và yi (xi: chẵn, yi: lẻ)
                xi_value = individual[j]  # Lấy xi (vị trí chẵn)
                yi_value = individual[j + 1] if j + 1 < len(individual) else 0  # Lấy yi (vị trí lẻ), mặc định 0 nếu thiếu

                # Kiểm tra và giới hạn giá trị xi_value
                if not isinstance(xi_value, int):  
                    print(f"⚠️ Cảnh báo: xi_value ({xi_value}) không phải số nguyên. Đặt về giá trị mặc định 0.")
                    xi_value = 0
                
                xi_value = max(0, min(xi_value, 12))

                # Kiểm tra nếu xi nằm ngoài phạm vi danh sách fitness_investment
                if xi_value >= len(fitness_investment):
                    print(f"⚠️ Cảnh báo: xi_value ({xi_value}) vượt phạm vi fitness_investment. Đặt về giá trị hợp lệ gần nhất.")
                    xi_value = len(fitness_investment) - 1  # Đặt xi về giá trị lớn nhất có thể

                fitness_xi = fitness_investment[xi_value]  # Lấy giá trị fitness tương ứng

                # Kiểm tra và xử lý giá trị yi_value
                if yi_value is None or not isinstance(yi_value, (int, float)) or yi_value < 0:
                    print(f"⚠️ Cảnh báo: yi_value ({yi_value}) không hợp lệ. Đặt về giá trị mặc định 0.")
                    yi_value = 0
                
                individual_fitness += fitness_xi * (yi_value / 100)  # Tính đóng góp của xi và yi

            fitness_values.append(individual_fitness)  # Lưu tổng fitness của cá thể này vào danh sách

        return fitness_values
