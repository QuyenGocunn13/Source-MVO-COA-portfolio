import numpy as np
from collections import defaultdict
import random
import csv

# Import Class
from algorithms.COA_Algorithm import COA
from algorithms.MVO_Algorithm import MVO
from Caculate_Fitness_Individual_Generator import Caculate_Fitness_Individual_Generator


# Thuật toán kết hợp MVO-COA
class HybridCOA_MVO:
    def __init__(self, population, fitness, bounds, max_iter, switch_iter, fitness_investment, replacement_map1, categories, criteria_manager):
        self.population = population  
        self.fitness = fitness
        if len(self.fitness) == 0:
            raise ValueError("⚠️ Error: Fitness array is empty during initialization!")
        self.bounds = bounds  
        self.max_iter = max_iter  
        self.switch_iter = switch_iter  
        self.fitness_investment = fitness_investment  

        # Xác định cá thể tốt nhất ban đầu
        self.best_solution = self.population[np.argmin(self.fitness)].copy()  
        self.best_fitness = np.min(self.fitness)  

        self.WEPmin = 0.2  
        self.WEPmax = 0.8  
        self.TDR = 1.0  

        self.mvo = MVO(bounds, self.WEPmax, self.TDR)
        self.coa = COA(len(population[0]), fitness_investment, len(population), population.copy())
        
        self.replacement_map = self.read_replacement_map_from_csv(replacement_map1)
        self.categories = self.read_categories_from_csv(categories)
        self.criteria_manager = criteria_manager

        # Dữ liệu từ CriteriaManager
        self.investment_names = self.criteria_manager.investment_names
        self.criteria_estimated = self.criteria_manager.criteria_estimated
        self.risk_estimated = self.criteria_manager.risk_estimated

    def update_population_mvo(self, WEP, TDR):
        self.mvo.WEP = WEP
        self.mvo.TDR = TDR
        new_population = self.mvo.update_population(self.population, self.fitness, self.best_solution)

        # Giữ lại cá thể tốt nhất trong quần thể mới
        worst_idx = np.argmax(self.fitness)
        new_population[worst_idx] = self.best_solution.copy()

        # Làm tròn các giá trị cá thể trong quần thể
        new_population = [
            [np.round(val, 2) if isinstance(val, (float, np.float64)) else val for val in individual]
            for individual in new_population
        ]
        return new_population

    def update_population_coa(self):
        self.coa.population = self.population.copy()
        new_population = self.coa.update_population(self.population, self.fitness, self.best_solution)

        if not new_population:
            raise ValueError("⚠️ Error: COA.update_population() returned an empty population.")

        worst_idx = np.argmax(self.fitness)  
        new_population[worst_idx] = self.best_solution.copy()

        new_population = [
            [np.round(val, 2) if isinstance(val, (float, np.float64)) else val for val in individual]
            for individual in new_population
        ]
        self.population = new_population

    def read_replacement_map_from_csv(self, replacement_map_file):
        replacement_map = {}

        try:
            with open(replacement_map_file, "r", encoding="utf-8") as f:
                reader = csv.reader(f)
                header = next(reader)  # Đọc dòng tiêu đề

                for row in reader:
                    if len(row) == 2:  # Kiểm tra số cột hợp lệ
                        category, subcategories = row
                        replacement_map[category] = subcategories.split(", ")  # Tách danh sách các mục thay thế
        except Exception as e:
            print(f"Lỗi khi đọc tệp CSV {replacement_map_file}: {e}")

        return replacement_map

    def read_categories_from_csv(self, categories_file):
        categories = {}

        try:
            with open(categories_file, mode="r", encoding="utf-8") as file:
                reader = csv.reader(file)
                next(reader)  # Bỏ qua dòng tiêu đề

                for row in reader:
                    if len(row) == 2:
                        category, subcategory = row
                        if category not in categories:
                            categories[category] = []
                        categories[category].append(subcategory)
        except Exception as e:
            print(f"Lỗi khi đọc tệp CSV {categories_file}: {e}")

        return categories

    def classify_investments(self, best_solution_investment):
        classified_investments = defaultdict(list)
        categories_lower = {category: [name.lower() for name in names] for category, names in self.categories.items()}
        default_category = "Khác"

        for i in range(0, len(best_solution_investment), 2):
            xi_investment = best_solution_investment[i]
            yi_investment = best_solution_investment[i + 1]

            if not (0 <= xi_investment < len(self.investment_names)):
                xi_investment = random.randint(0, len(self.investment_names) - 1)

            investment_name = self.investment_names[xi_investment].lower().capitalize()
            matched = False
            for category, names in categories_lower.items():
                if investment_name in names:
                    classified_investments[category].append((investment_name, yi_investment))
                    matched = True
                    break
            if not matched:
                classified_investments[default_category].append((investment_name, yi_investment))

        for category in classified_investments:
            classified_investments[category].sort(key=lambda x: x[1], reverse=True)

        return classified_investments

    def penalize_fitness(self, fitness_value):
        return fitness_value * 1.5
    
    def check_and_replace_duplicate_categories(self, solution, fitness_value):
        classified_investments = self.classify_investments(solution)
        duplicate_categories = {cat for cat, items in classified_investments.items() if len(items) > 1}

        if duplicate_categories:
            #print(f"⚠️ Warning: Duplicate categories detected - {duplicate_categories}")

            for category in duplicate_categories:
                if category in self.replacement_map:
                    alternatives = self.replacement_map[category]

                    # **Tìm danh mục có phần trăm phân bổ lớn nhất**
                    max_allocation_idx = None
                    max_allocation_value = 0
                
                    for i in range(0, len(solution), 2):
                        xi = solution[i]
                        yi = solution[i + 1]  # Phần trăm phân bổ
                    
                        investment_name = self.investment_names[xi].lower().capitalize()
                    
                        if investment_name in [item[0] for item in classified_investments[category]]:
                            if yi > max_allocation_value:
                                max_allocation_value = yi
                                max_allocation_idx = i + 1  # Chỉ số của phần trăm phân bổ

                    # **Thay thế danh mục trùng lặp**
                    for i in range(0, len(solution), 2):
                        xi = solution[i]
                        investment_name = self.investment_names[xi].lower().capitalize()

                        if investment_name in [item[0] for item in classified_investments[category]]:
                            replacement_name = random.choice(alternatives)
                            if replacement_name in self.investment_names:
                                new_index = self.investment_names.index(replacement_name)
                                solution[i] = new_index
                                #print(f"🔄 Replacing {investment_name} with {replacement_name} in category {category}")

                                # **Giảm phần trăm phân bổ nếu đây là danh mục có phần trăm cao nhất**
                                if max_allocation_idx is not None and i + 1 == max_allocation_idx:
                                    solution[max_allocation_idx] *= 0.8  # Giảm 20%
                                    #print(f"⬇️ Reducing allocation of {investment_name} to {solution[max_allocation_idx]:.2f}%")

                    # **Chuẩn hóa lại phần trăm phân bổ để tổng = 100%**
                    total_allocation = sum(solution[i + 1] for i in range(0, len(solution), 2))
                    if total_allocation > 0:
                        for i in range(1, len(solution), 2):
                            solution[i] = max(1, (solution[i] / total_allocation) * 100)

            # **Phạt cá thể do có danh mục trùng lặp**
            fitness_value = self.penalize_fitness(fitness_value)

        return solution, fitness_value

    def run(self):
        for iter in range(self.max_iter):
            WEP = self.WEPmin + (iter / self.max_iter) * (self.WEPmax - self.WEPmin)
            self.TDR = 1 - (iter / self.max_iter)

            if iter < self.switch_iter:
                self.population = self.update_population_mvo(WEP, self.TDR)
            else:
                self.update_population_coa()

            if not self.population:
                raise ValueError("⚠️ Error: Population is empty after update!")

            fitness_current = Caculate_Fitness_Individual_Generator.calculate_fitness(
                self.fitness_investment, self.population
            )
            current_best_idx = np.argmin(fitness_current)
            current_best_fitness = fitness_current[current_best_idx]
            current_best_solution = self.population[current_best_idx].copy()


            sorted_indices = np.argsort(self.criteria_manager.weights)[-3:]
            
            if self.criteria_manager.weights[6] in sorted_indices:
                # **Gọi hàm kiểm tra & thay thế danh mục trùng lặp**
                current_best_solution, current_best_fitness = self.check_and_replace_duplicate_categories(
                    current_best_solution, current_best_fitness
                )

            # **Cập nhật cá thể tốt nhất**
            if current_best_fitness < self.best_fitness:
                self.best_fitness = current_best_fitness
                self.best_solution = current_best_solution.copy()

            print(f"* Iteration {iter + 1}:")
            print(f"Best Solution: {current_best_solution}")
            print(f"Best Fitness: {current_best_fitness:.15f}")
        
        print (f"=> Best fitness in History: {self.best_fitness}")

        return self.best_solution, self.best_fitness
