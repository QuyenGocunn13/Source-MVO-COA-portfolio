import numpy as np
# Thuật toán MVO
class MVO:
    def __init__(self, bounds, WEP, TDR):
        self.bounds = bounds  # Giới hạn tìm kiếm
        self.WEP = WEP  # Hệ số kiểm soát trọng số lỗ sâu
        self.TDR = TDR  # Hệ số điều chỉnh

    def normalize_inflation_rate(self, fitness):
        """Chuẩn hóa tỷ lệ lạm phát dựa trên giá trị fitness."""
        fitness = np.array(fitness)
        total_fitness = np.sum(fitness)
        if total_fitness == 0:
            return np.ones_like(fitness) / len(fitness)  # Tránh chia cho 0
        epsilon = 1e-6  # Tránh lỗi chia 0
        normalized_fitness = 1 / (fitness + epsilon)
        return normalized_fitness / np.sum(normalized_fitness)

    def roulette_wheel_selection(self, probabilities):
        """Lựa chọn dựa trên xác suất bằng phương pháp vòng quay roulette."""
        cumulative_sum = np.cumsum(probabilities)
        random_number = np.random.rand()
        return np.searchsorted(cumulative_sum, random_number)

    def adjust_yi_values(self, yi_values):
        """
        Điều chỉnh yi sao cho:
        - Mỗi phần tử yi > 5
        - Tổng yi = 100
        """
        yi_values = np.array(yi_values, dtype=float)
        n = len(yi_values)
        
        # Kiểm tra điều kiện khả thi
        min_value = 5.01  # để đảm bảo > 5
        min_total = n * min_value
        if min_total > 100:
            raise ValueError(f"Số phần tử ({n}) quá nhiều để đảm bảo mỗi yi > 5%.")

        # Loại bỏ giá trị âm và nhỏ, đảm bảo tất cả dương
        yi_values = np.where(yi_values < 0, 0, yi_values)

        # Nếu tất cả bằng 0, sinh mới từ Dirichlet
        if np.sum(yi_values) == 0:
            yi_values = np.random.dirichlet(np.ones(n))

        # Chuẩn hóa lại tổng = 1
        yi_values = yi_values / np.sum(yi_values)

        # Phân bổ phần dư sau khi đảm bảo mỗi phần tử > 5
        remaining = 100 - n * min_value
        yi_values = yi_values * remaining + min_value

        # Làm tròn đến 2 chữ số và cân chỉnh sai số
        yi_values = np.round(yi_values, 2)
        difference = 100 - np.sum(yi_values)
        if abs(difference) > 0:
            max_index = np.argmax(yi_values)
            yi_values[max_index] = np.round(yi_values[max_index] + difference, 2)

        # Đảm bảo sau cùng vẫn > 5
        yi_values = np.where(yi_values <= 5, min_value, yi_values)

        return yi_values


    def update_population(self, population, fitness, best_solution):
        """Cập nhật quần thể theo thuật toán MVO."""
        new_population = [ind[:] for ind in population]
        best_fitness = np.min(fitness)
        NI = self.normalize_inflation_rate(fitness)
        sorted_indices = np.argsort(fitness)
        SU = [population[i] for i in sorted_indices]

        for i in range(len(population)):
            original_xi = [population[i][j] for j in range(0, len(population[i]), 2)]

            if fitness[i] > best_fitness:
                r1 = np.random.rand()
                if r1 < NI[i]:
                    # White Hole: Cập nhật yi từ cá thể được chọn
                    white_hole_index = self.roulette_wheel_selection(NI)
                    new_yis = [
                        max(SU[white_hole_index][2 * j + 1] * np.random.uniform(0.5, 1.5), 0)
                        for j in range(len(population[i]) // 2)
                    ]
                else:
                    # Wormhole: Cập nhật yi dựa trên best_solution + yếu tố ngẫu nhiên
                    n = len(best_solution) // 2
                    new_yis = []
                    for j in range(n):
                        r3, r4 = np.random.rand(), np.random.rand()
                        yi_value = best_solution[2 * j + 1] + self.TDR * (((self.bounds[1] - self.bounds[0]) * r4) + self.bounds[0])
                        new_yis.append(np.round(max(yi_value, 0), 2))  # Đảm bảo yi > 0

                # Chuẩn hóa `yi` để tổng luôn là 100
                new_yis = self.adjust_yi_values(new_yis)

                # Cập nhật giá trị mới vào quần thể
                for j in range(len(new_yis)):
                    new_population[i][2 * j + 1] = new_yis[j]
            else:
                new_population[i] = population[i][:]  # Giữ nguyên cá thể cũ nếu fitness tốt hơn

            # Giữ nguyên giá trị xi
            for j, xi in enumerate(original_xi):
                new_population[i][2 * j] = xi

        return new_population
