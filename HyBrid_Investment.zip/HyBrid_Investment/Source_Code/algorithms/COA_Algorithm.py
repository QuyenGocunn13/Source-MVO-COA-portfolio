import numpy as np
import random
import copy
# Thuật toán COA
class COA:
    def __init__(self, n_bien, fitness_investment, pop_size, init_population):
        self.n_bien = n_bien // 2  # Số lượng cặp biến (xi, yi)
        self.fitness_investment = fitness_investment  # Mảng giá trị fitness
        self.pop_size = pop_size  # Kích thước quần thể
        self.new_population_coa = copy.deepcopy(init_population)

    def create_individual(self):
        """Tạo một cá thể mới gồm n_bien giá trị xi, yi xen kẽ."""
        n = self.n_bien
        individual = [0] * (2 * n)  # Cá thể chứa đủ 2*n giá trị

        # Tạo các giá trị xi ngẫu nhiên
        xi_values = random.sample(range(14), k=n)
        for i, xi in enumerate(xi_values):
            individual[2 * i] = xi  # Xi ở vị trí chẵn

        # Tạo các giá trị yi từ phân phối Dirichlet, đảm bảo tổng 100
        yi_values = np.random.dirichlet(np.ones(n)) * 100
        yi_values = np.round(yi_values, 2)
        # Cân chỉnh tổng về 100 nếu có sai lệch do làm tròn
        yi_values[np.argmax(yi_values)] += 100 - np.sum(yi_values)

        for i, yi in enumerate(yi_values):
            individual[2 * i + 1] = yi  # Yi ở vị trí lẻ

        return individual
    
    def update_population(self, population, fitness, best_solution):
        if population is None or best_solution is None:
            raise ValueError("population or best_solution is None. Please check the input.")
        if not population:
            raise ValueError("population is empty.")

        self.new_population_coa = copy.deepcopy(population)

        # Tính individual_fitness_G từ iguana_G
        iguana = best_solution.copy()
        iguana_G = self.create_individual()
        if iguana_G is None:
            raise ValueError("create_individual() returned None.")
        if self.fitness_investment is None:
            raise ValueError("fitness_investment is None.")

        individual_fitness_G = sum(
            self.fitness_investment[iguana_G[j]] * iguana_G[j + 1]
            if 0 <= iguana_G[j] < len(self.fitness_investment) else 0
            for j in range(0, len(iguana_G), 2)
        )

        # Cập nhật từng cá thể trong quần thể
        for i in range(self.pop_size):
            new_individual = population[i][:]
            used_xi = set()
            possible_xis = list(range(13))
            I = random.choice([1, 2])

            # Lưu yi ban đầu
            original_yi = [population[i][j+1] for j in range(0, len(population[i]), 2)]

            # Nhánh COA
            if i >= self.pop_size // 2:
                # Nhánh Iguana trên Coati
                for j in range(0, len(iguana_G), 2):
                    xi_value = population[i][j]
                    yi_value = original_yi[j//2]
                    r = random.random()

                    if individual_fitness_G < fitness[i]:
                        new_xi = int(round(xi_value + r * (iguana_G[j] - I * xi_value)))
                    else:
                        new_xi = int(round(xi_value + r * (xi_value - iguana_G[j])))

                    new_xi = max(0, min(12, new_xi))
                    # Đảm bảo xi không trùng
                    choices = set(possible_xis) - used_xi
                    while new_xi in used_xi:
                        if not choices:
                            choices = set(possible_xis) - used_xi
                        new_xi = random.choice(list(choices))
                        choices.discard(new_xi)

                    used_xi.add(new_xi)
                    new_individual[j]     = new_xi
                    new_individual[j + 1] = yi_value
            else:
                # Nhánh Coati đe dọa Iguana
                for j in range(0, len(population[i]), 2):
                    xi_value = population[i][j]
                    yi_value = original_yi[j//2]
                    r = random.random()

                    new_xi = int(round(xi_value + r * (iguana[j] - I * xi_value)))
                    new_xi = max(0, min(12, new_xi))
                    # Đảm bảo xi không trùng
                    choices = set(possible_xis) - used_xi
                    while new_xi in used_xi:
                        if not choices:
                            choices = set(possible_xis) - used_xi
                        new_xi = random.choice(list(choices))
                        choices.discard(new_xi)

                    used_xi.add(new_xi)
                    new_individual[j]     = new_xi
                    new_individual[j + 1] = yi_value

            self.new_population_coa[i] = new_individual.copy()

        return self.new_population_coa