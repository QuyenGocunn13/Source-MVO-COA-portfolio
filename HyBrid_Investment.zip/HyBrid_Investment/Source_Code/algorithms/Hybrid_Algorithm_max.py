import os
import numpy as np
from collections import defaultdict
import random
import csv

from algorithms.COA_Algorithm import COA
from algorithms.MVO_Algorithm import MVO
from Caculate_Fitness_Individual_Generator import Caculate_Fitness_Individual_Generator

class HybridCOA_MVO:
    def __init__(self, population, fitness, bounds, max_iter, switch_iter, fitness_investment,
                 replacement_map_file, categories_file, criteria_manager, file_path=None):

        self.population = population  
        self.fitness = fitness
        if len(self.fitness) == 0:
            raise ValueError("⚠️ Error: Fitness array is empty during initialization!")
        self.bounds = bounds  
        self.max_iter = max_iter  
        self.switch_iter = switch_iter  
        self.fitness_investment = fitness_investment  

        self.best_solution = self.population[np.argmax(self.fitness)].copy()  
        self.best_fitness = np.max(self.fitness)   

        self.WEPmin = 0.2  
        self.WEPmax = 0.8  
        self.TDR = 1.0  

        self.mvo = MVO(bounds, self.WEPmax, self.TDR)
        self.coa = COA(len(population[0]), fitness_investment, len(population), population.copy())

        if file_path is None:
            current_dir = os.path.dirname(__file__)
            file_path = os.path.join(current_dir, "database")

        replacement_map_path = os.path.join(file_path, replacement_map_file)
        categories_path = os.path.join(file_path, categories_file)

        self.replacement_map = self.read_replacement_map_from_csv(replacement_map_path)
        self.categories = self.read_categories_from_csv(categories_path)
        self.criteria_manager = criteria_manager

        self.investment_names = self.criteria_manager.investment_names
        self.criteria_estimated = self.criteria_manager.criteria_estimated
        self.risk_estimated = self.criteria_manager.risk_estimated

    def update_population_mvo(self, WEP, TDR):
        self.mvo.WEP = WEP
        self.mvo.TDR = TDR
        new_population = self.mvo.update_population(self.population, self.fitness, self.best_solution)

        worst_idx = np.argmax(self.fitness)
        new_population[worst_idx] = self.best_solution.copy()

        new_population = [
            [np.round(val, 2) if isinstance(val, (float, np.float64)) else val for val in individual]
            for individual in new_population
        ]
        return new_population

    def update_population_coa(self):
        self.coa.population = self.population.copy()
        new_population = self.coa.update_population(self.population, self.fitness, self.best_solution)

        if not new_population:
            raise ValueError("⚠️ Error: COA.update_population() returned an empty population.")

        worst_idx = np.argmax(self.fitness)  
        new_population[worst_idx] = self.best_solution.copy()

        new_population = [
            [np.round(val, 2) if isinstance(val, (float, np.float64)) else val for val in individual]
            for individual in new_population
        ]
        self.population = new_population

    def read_replacement_map_from_csv(self, file_path):
        replacement_map = {}
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                reader = csv.reader(f)
                next(reader)
                for row in reader:
                    if len(row) == 2:
                        category, subcategories = row
                        replacement_map[category] = subcategories.split(", ")
        except Exception as e:
            print(f"Lỗi khi đọc tệp CSV {file_path}: {e}")
        return replacement_map

    def read_categories_from_csv(self, file_path):
        categories = {}
        try:
            print(f"✅ Đang đọc file: {file_path}")
            with open(file_path, mode="r", encoding="utf-8") as file:
                reader = csv.DictReader(file)  # Đọc với tiêu đề
                for row in reader:
                    category = row.get('Danh mục', '').strip()
                    subcategory = row.get('Danh mục con', '').strip()
                    if category and subcategory:
                        categories.setdefault(category, []).append(subcategory)
            print(f"✅ Đọc thành công: {len(categories)} danh mục.")
        except Exception as e:
            print(f"⚠️ Lỗi khi đọc tệp CSV {file_path}: {e}")
        return categories

    def classify_investments(self, best_solution_investment):
        classified_investments = defaultdict(list)
        categories_lower = {
            category: [name.lower() for name in names] for category, names in self.categories.items()
        }
        default_category = "Khác"

        for i in range(0, len(best_solution_investment), 2):
            xi = best_solution_investment[i]
            yi = best_solution_investment[i + 1]

            if not (0 <= xi < len(self.investment_names)):
                xi = random.randint(0, len(self.investment_names) - 1)

            name = self.investment_names[xi].lower().capitalize()
            matched = False

            for category, names in categories_lower.items():
                if name in names:
                    classified_investments[category].append((name, yi))
                    matched = True
                    break

            if not matched:
                classified_investments[default_category].append((name, yi))

        for category in classified_investments:
            classified_investments[category].sort(key=lambda x: x[1], reverse=True)

        return classified_investments

    def penalize_fitness(self, fitness_value):
        return fitness_value * 0.5
    def check_and_replace_duplicate_categories(self, solution, fitness_value):
        """
        Phát hiện và thay thế một mục trùng lặp, giảm giá trị yi và phạt fitness.
        """
        # Phân loại theo category: {category: [(idx_xi, yi), ...]}
        classified = self.classify_investments(solution)
        duplicates = {cat: items for cat, items in classified.items() if len(items) > 1}
        if not duplicates:
            return solution, fitness_value

        # Xử lý chỉ một category trùng (nếu muốn nhiều có thể lặp)
        # Lấy category đầu tiên
        category, items = next(iter(duplicates.items()))
        # Chỉ thay nếu có map thay thế
        if category in self.replacement_map and items:
            # Chọn mục có yi cao nhất
            replace_idx, yi_val = max(items, key=lambda x: x[1])
            # Chọn replacement index mới
            existing = {self.investment_names[solution[idx]] for idx, _ in items}
            alternatives = [alt for alt in self.replacement_map[category] if alt not in existing]
            if alternatives:
                replacement_name = random.choice(alternatives)
                new_xi = next((i for i, d in enumerate(self.criteria_and_risk) if d['Danh mục'] == replacement_name), None)
                if new_xi is not None:
                    # Thay index và giảm yi
                    solution[replace_idx] = new_xi
                    yi_pos = replace_idx + 1
                    solution[yi_pos] = max(1, yi_val * 0.8)
                    # Phạt fitness
                    fitness_value = self.penalize_fitness(fitness_value)

        return solution, fitness_value

    def run(self):
        for iter in range(self.max_iter):
            WEP = self.WEPmin + (iter / self.max_iter) * (self.WEPmax - self.WEPmin)
            self.TDR = 1 - (iter / self.max_iter)

            if iter < self.switch_iter:
                self.population = self.update_population_mvo(WEP, self.TDR)
            else:
                self.update_population_coa()

            if not self.population:
                raise ValueError("⚠️ Error: Population is empty after update!")

            fitness_current = Caculate_Fitness_Individual_Generator.calculate_fitness(
                self.fitness_investment, self.population
            )
            current_best_idx = np.argmax(fitness_current)
            current_best_fitness = fitness_current[current_best_idx]
            current_best_solution = self.population[current_best_idx].copy()

            sorted_indices = np.argsort(self.criteria_manager.weights)[-3:][::-1]
            top3_values = self.criteria_manager.weights[sorted_indices]

            if self.criteria_manager.weights[6] in top3_values:
                current_best_solution, current_best_fitness = self.check_and_replace_duplicate_categories(
                    current_best_solution, current_best_fitness
                )

            if current_best_fitness > self.best_fitness:
                self.best_fitness = current_best_fitness
                self.best_solution = current_best_solution.copy()

        return self.best_solution
