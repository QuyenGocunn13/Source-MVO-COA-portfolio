import os
import csv
from tabulate import tabulate

# Xác định đường dẫn gốc tương đối với file đang chạy
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE_DIR = os.path.join(BASE_DIR, "database")

def display_ahp_results(weights):
    print("\nTrọng số cuối cùng cho các tiêu chí:")

    criteria_names = [
        "Lợi nhuận kỳ vọng", "Rủi ro", "Thanh khoản", "Thời gian đầu tư",
        "Chi phí", "Ổn định của dòng tiền", "Đa dạng hóa"
    ]

    # Ghép trọng số với chỉ số ban đầu
    indexed_weights = list(enumerate(weights))

    # Sắp xếp theo trọng số giảm dần
    sorted_weights = sorted(indexed_weights, key=lambda x: x[1], reverse=True)

    ranked_data = []
    current_rank = 1
    prev_weight = None
    tie_count = 0

    for i, (idx, weight) in enumerate(sorted_weights):
        if weight == prev_weight:
            tie_count += 1
        else:
            current_rank = current_rank + tie_count
            tie_count = 1
        prev_weight = weight
        ranked_data.append([criteria_names[idx], weight, current_rank])

    print(tabulate(ranked_data, headers=["Criterias", "Criteria Weights", "Rank"], tablefmt="fancy_grid"))

    os.makedirs(DATABASE_DIR, exist_ok=True)
    output_file = os.path.join(DATABASE_DIR, "ahp_results.csv")
    with open(output_file, mode="w", encoding="utf-8", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["Criteria", "Weight", "Rank"])
        writer.writerows(ranked_data)

    print(f"✅ Đã lưu kết quả AHP vào {output_file}")
