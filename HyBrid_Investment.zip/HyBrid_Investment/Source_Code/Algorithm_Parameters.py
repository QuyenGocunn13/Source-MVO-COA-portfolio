import random
import csv
import os
import pandas as pd

class AlgorithmParameters:
    """Cấu hình cho thuật toán tối ưu đầu tư."""

    def __init__(self, max_iter=50, pop_size=100, bounds=(-1, 1)):
        BASE_DIR = os.path.dirname(os.path.abspath(__file__))
        DATABASE_DIR = os.path.join(BASE_DIR, "data_customer")
        file_path = os.path.join(DATABASE_DIR, "weights_update.csv")

        config = self.load_weights_from_csv(file_path)

        try:
            self.pop_size = int(config.get("population_size", pop_size))
        except (ValueError, TypeError):
            self.pop_size = pop_size

        try:
            self.max_iter = int(config.get("max_iter", max_iter))
        except (ValueError, TypeError):
            self.max_iter = max_iter

        try:
            self.dimensions = int(config.get("dimensions", 5))
        except (ValueError, TypeError):
            self.dimensions = 5

        try:
            lower = float(config.get("lower_bound", bounds[0]))
            upper = float(config.get("upper_bound", bounds[1]))
            self.bounds = (lower, upper)
        except (ValueError, TypeError):
            self.bounds = bounds

        self.switch_iter = self.max_iter // 2  # chia nguyên

        self.data = self.load_criteria_from_csv()
        self.save_criteria_to_csv()


    def load_weights_from_csv(self, file_path):
        try:
            df = pd.read_csv(file_path, encoding="utf-8-sig")
            if not df.empty:
                return df.iloc[0].to_dict()
            
        except Exception as e:
            print(f"⚠️ Lỗi khi đọc file CSV: {e}. Sử dụng giá trị mặc định.")
        
        return {}


    def load_criteria_from_csv(self):
        """Hàm đọc dữ liệu từ file CSV hoặc tạo dữ liệu ngẫu nhiên nếu file không tồn tại hoặc lỗi."""
        BASE_DIR = os.path.dirname(os.path.abspath(__file__))
        DATABASE_DIR = os.path.join(BASE_DIR, "data_customer")
        file_path = os.path.join(DATABASE_DIR, "weights.csv")
        
        # Dữ liệu mặc định nếu không thể đọc file
        default_data = [
            random.randint(1, 20),  # Lợi nhuận (Positive)
            random.randint(1, 15),  # Rủi ro (Negative)
            random.randint(1, 20),  # Thanh khoản (Positive)
            random.randint(1, 20),  # Thời gian đầu tư (Average)
            random.randint(1, 15),  # Chi phí (Negative)
            random.randint(1, 20),  # Ổn định dòng tiền (Positive)
            random.randint(1, 20),  # Đa dạng hóa (Average)
        ]

        try:
            # Kiểm tra file có tồn tại không
            if not os.path.exists(file_path):
                print(f"⚠️ File '{file_path}' không tồn tại. Dùng dữ liệu ngẫu nhiên.")
                return default_data

            # Đọc file CSV
            with open(file_path, mode="r", encoding="utf-8-sig") as file:
                csv_reader = csv.DictReader(file)
                data = []
                for row in csv_reader:
                    # Lấy giá trị cột "Trọng số" và chuyển thành float
                    if "Trọng số" in row:
                        data.append(float(row["Trọng số"]))
                    else:
                        raise KeyError("⚠️ Cột 'Trọng số' không tồn tại trong file CSV.")
                
                if len(data) == 0:
                    raise ValueError("⚠️ File CSV không chứa dữ liệu. Dùng dữ liệu ngẫu nhiên.")
                
                #print("✅ Dữ liệu từ CSV:", data)
                return data

        except (FileNotFoundError, KeyError, ValueError) as e:
            print(f"{e} Dùng dữ liệu ngẫu nhiên.")
            return default_data

        except Exception as e:
            print(f"⚠️ Lỗi không xác định: {e}. Dùng dữ liệu ngẫu nhiên.")
            return default_data
        
    def save_criteria_to_csv(self):
        """Lưu tiêu chí vào file CSV."""
        base_dir = os.path.dirname(os.path.abspath(__file__))
        file_path = os.path.join(base_dir, "database", "criteria_data.csv")
        os.makedirs(os.path.dirname(file_path), exist_ok=True)

        with open(file_path, mode="w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["Value"])
            for value in self.data:
                writer.writerow([value])

    def get_parameters(self):
        """Trả về dictionary các tham số."""
        return {
            "pop_size": self.pop_size,
            "bounds": self.bounds,
            "max_iter": self.max_iter,
            "switch_iter": self.switch_iter,
            "data": self.data
        }
