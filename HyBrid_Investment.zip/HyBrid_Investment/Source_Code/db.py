import psycopg2
from psycopg2 import pool
import os
from dotenv import load_dotenv

# Nạp biến môi trường từ file .env
load_dotenv()

connection_pool = None

try:
    connection_pool = psycopg2.pool.SimpleConnectionPool(
        1, 10,  # minconn, maxconn
        dbname=os.getenv('DB_NAME'),
        user=os.getenv('DB_USER'),
        password=os.getenv('DB_PASSWORD'),
        host=os.getenv('DB_HOST'),
        port=os.getenv('DB_PORT')
    )
    if connection_pool:
        print("✅ Kết nối PostgreSQL thành công!")
except Exception as e:
    print("❌ Lỗi khi kết nối đến PostgreSQL:", e)

# Hàm lấy và trả kết nối
def get_conn():
    return connection_pool.getconn()

def put_conn(conn):
    connection_pool.putconn(conn)
