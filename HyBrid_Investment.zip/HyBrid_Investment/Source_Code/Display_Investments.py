import os
import csv
import random
from tabulate import tabulate
from collections import defaultdict

class DisplayInvestmentsByCategory:
    def __init__(self, criteria_manager, categories_file, file_path):
        self.criteria_manager = criteria_manager
        self.investment_names = self.criteria_manager.investment_names
        self.criteria_estimated = self.criteria_manager.criteria_estimated
        self.risk_estimated = self.criteria_manager.risk_estimated

        # Định nghĩa thư mục database, đảm bảo tồn tại
        self.database_dir = file_path
        os.makedirs(self.database_dir, exist_ok=True)

        # Đọc danh mục từ CSV
        self.categories_file = os.path.join(self.database_dir, categories_file)
        self.categories = self.read_categories_from_csv(self.categories_file)
    
    def read_categories_from_csv(self, categories_file):
        categories = {}
        try:
            with open(categories_file, mode="r", encoding="utf-8") as file:
                reader = csv.reader(file)
                next(reader)  # Bỏ qua dòng tiêu đề
                for row in reader:
                    if len(row) == 2:
                        category, subcategory = row
                        if category not in categories:
                            categories[category] = []
                        categories[category].append(subcategory)
        except Exception as e:
            print(f"Lỗi khi đọc tệp CSV {categories_file}: {e}")
        return categories
    
    def classify_investments(self, best_solution_investment):
        classified_investments = defaultdict(list)
        xi_investments = []
        
        categories_lower = {
            category: [name.lower() for name in names] for category, names in self.categories.items()
        }
        default_category = "Khác"

        for i in range(0, len(best_solution_investment), 2):
            xi_investment = best_solution_investment[i]
            yi_investment = best_solution_investment[i + 1]

            if not (0 <= xi_investment < len(self.investment_names)):
                xi_investment = random.randint(0, len(self.investment_names) - 1)
            
            xi_investments.append(int(xi_investment))

            investment_name = self.investment_names[xi_investment].lower().capitalize()
            matched = False
            for category, names in categories_lower.items():
                if investment_name in names:
                    classified_investments[category].append((investment_name, yi_investment))
                    matched = True
                    break
            if not matched:
                classified_investments[default_category].append((investment_name, yi_investment))

        for category in classified_investments:
            classified_investments[category].sort(key=lambda x: x[1], reverse=True)
            
        return classified_investments, xi_investments
    
    def display_investments_by_category(self, classified_investments, best_solution_investment):
        idx_with_weights = []
        for i in range(0, len(best_solution_investment), 2):
            xi = best_solution_investment[i]
            yi = best_solution_investment[i+1]
            idx_with_weights.append((xi, yi))

        idx_with_weights.sort(key=lambda pair: pair[1], reverse=True)

        selected_investments = []
        for category, investments in classified_investments.items():
            for investment_name, yi_investment in investments:
                if (investment_name, yi_investment, category) not in selected_investments:
                    selected_investments.append((investment_name, yi_investment, category))

        table_data = []
        for rank, ((xi, yi), (name, weight, category)) in enumerate(zip(idx_with_weights, selected_investments), start=0):
            invest_index = xi 
            estimated_return = self.criteria_estimated[invest_index] if invest_index < len(self.criteria_estimated) else "N/A"
            risk             = self.risk_estimated[invest_index]      if invest_index < len(self.risk_estimated)      else "N/A"
            table_data.append([
                str(rank + 1),
                name,
                f"{weight:.2f}%",
                estimated_return,
                risk
            ])

        print("\n\U0001F4CC Danh sách danh mục tối ưu nhất:")
        print(tabulate(
            table_data,
            headers=["STT", "Danh mục đầu tư", "Trọng số (%)", "Lợi nhuận ước tính", "Rủi ro ước tính"],
            tablefmt="fancy_grid"
        ))

        self.save_to_csv(table_data)


    def save_to_csv(self, table_data):
        csv_file_path = os.path.join(self.database_dir, "investment_results.csv")
        with open(csv_file_path, mode="w", encoding="utf-8", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["STT", "Danh mục đầu tư", "Trọng số (%)", "Lợi nhuận ước tính", "Rủi ro ước tính"])
            writer.writerows(table_data)
        print(f"✅ Đã lưu danh mục đầu tư vào {csv_file_path}")